import json
import os
from datetime import datetime

class DataService:
    def __init__(self):
        self.data_dir = os.path.join(os.getcwd(), "data")
    
    # ============= ATTENDANCE METHODS =============
    def get_employee_attendance(self, emp_id: str, limit: int = 10):
        """Get attendance records for an employee"""
        attendance_path = os.path.join(self.data_dir, "attendance.json")
        
        if os.path.exists(attendance_path):
            with open(attendance_path, "r") as f:
                data = json.load(f)
                records = [r for r in data.get("attendance_records", []) if r.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "total_records": len(records),
                    "records": records[-limit:]
                }
        
        return {"status": "error", "message": "No attendance data found"}
    
    def mark_attendance(self, emp_id: str, action: str = "check_in"):
        """Mark attendance check-in or check-out and persist to file"""
        attendance_path = os.path.join(self.data_dir, "attendance.json")
        now = datetime.now()
        
        # Load existing
        data = {"attendance_records": []}
        if os.path.exists(attendance_path):
            with open(attendance_path, "r") as f:
                data = json.load(f)
        
        record = {
            "emp_id": emp_id,
            "date": now.strftime("%Y-%m-%d"),
            "check_in": now.strftime("%H:%M:%S") if action == "check_in" else "N/A",
            "check_out": now.strftime("%H:%M:%S") if action == "check_out" else "N/A",
            "status": "present",
            "duration": "Active" if action == "check_in" else "Completed"
        }
        
        data["attendance_records"].append(record)
        
        with open(attendance_path, "w") as f:
            json.dump(data, f, indent=4)

        # Update workforce.json for real-time visualization
        workforce_path = os.path.join(self.data_dir, "workforce.json")
        if os.path.exists(workforce_path):
            with open(workforce_path, "r") as f:
                workforce = json.load(f)
            for emp in workforce:
                if emp["id"] == emp_id:
                    emp["status"] = "Active" if action == "check_in" else "Offline"
                    emp["clock_in"] = now.strftime("%I:%M %p") if action == "check_in" else emp.get("clock_in", "N/A")
                    break
            with open(workforce_path, "w") as f:
                json.dump(workforce, f, indent=4)
        
        return {
            "status": "success",
            "message": f"Attendance {action} recorded and synced",
            "record": record
        }
    
    # ============= WORK SCHEDULE METHODS =============
    def get_employee_schedule(self, emp_id: str):
        """Get work schedule for an employee"""
        schedule_path = os.path.join(self.data_dir, "work_schedule.json")
        
        if os.path.exists(schedule_path):
            with open(schedule_path, "r") as f:
                data = json.load(f)
                schedules = [s for s in data.get("schedules", []) if s.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "schedules": schedules
                }
        
        return {"status": "error", "message": "No schedule data found"}
    
    def get_org_schedule(self, org_id: str):
        """Get all schedules for organization"""
        schedule_path = os.path.join(self.data_dir, "work_schedule.json")
        
        if os.path.exists(schedule_path):
            with open(schedule_path, "r") as f:
                data = json.load(f)
                schedules = data.get("schedules", [])
                return {
                    "status": "success",
                    "org_id": org_id,
                    "total_schedules": len(schedules),
                    "schedules": schedules
                }
        
        return {"status": "error", "message": "No schedule data found"}
    
    # ============= PAYROLL METHODS =============
    def get_employee_payroll(self, emp_id: str):
        """Get payroll history for an employee"""
        payroll_path = os.path.join(self.data_dir, "payroll_data.json")
        
        if os.path.exists(payroll_path):
            with open(payroll_path, "r") as f:
                data = json.load(f)
                records = [r for r in data.get("payroll", []) if r.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "payroll_records": records
                }
        
        return {"status": "error", "message": "No payroll data found"}
    
    def get_org_payroll(self, org_id: str):
        """Get all payroll for organization"""
        payroll_path = os.path.join(self.data_dir, "payroll_data.json")
        
        if os.path.exists(payroll_path):
            with open(payroll_path, "r") as f:
                data = json.load(f)
                records = data.get("payroll", [])
                return {
                    "status": "success",
                    "org_id": org_id,
                    "total_payroll_records": len(records),
                    "payroll_records": records
                }
        
        return {"status": "error", "message": "No payroll data found"}
    
    # ============= LEAVE REQUEST METHODS =============
    def get_employee_leave_requests(self, emp_id: str):
        """Get leave requests for an employee"""
        leave_path = os.path.join(self.data_dir, "leave_requests.json")
        
        if os.path.exists(leave_path):
            with open(leave_path, "r") as f:
                data = json.load(f)
                requests = [r for r in data.get("leave_requests", []) if r.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "leave_requests": requests
                }
        
        return {"status": "error", "message": "No leave request data found"}
    
    def submit_leave_request(self, emp_id: str, emp_name: str, leave_type: str, 
                            start_date: str, end_date: str, reason: str):
        """Submit a new leave request"""
        leave_path = os.path.join(self.data_dir, "leave_requests.json")
        
        from datetime import datetime as dt
        start = dt.strptime(start_date, "%Y-%m-%d")
        end = dt.strptime(end_date, "%Y-%m-%d")
        duration = (end - start).days + 1
        
        new_request = {
            "id": f"leave-{int(datetime.now().timestamp())}",
            "emp_id": emp_id,
            "name": emp_name,
            "leave_type": leave_type,
            "start_date": start_date,
            "end_date": end_date,
            "duration": duration,
            "reason": reason,
            "status": "pending",
            "requested_date": datetime.now().strftime("%Y-%m-%d"),
            "approval_date": None
        }
        
        # Load existing and add new
        requests = []
        if os.path.exists(leave_path):
            with open(leave_path, "r") as f:
                data = json.load(f)
                requests = data.get("leave_requests", [])
        
        requests.append(new_request)
        
        # Save back
        os.makedirs(os.path.dirname(leave_path), exist_ok=True)
        with open(leave_path, "w") as f:
            json.dump({"leave_requests": requests}, f, indent=2)
        
        return {
            "status": "success",
            "message": "Leave request submitted",
            "request": new_request
        }
    
    def get_org_leave_requests(self, org_id: str):
        """Get all leave requests for a specific organization, or all if org_id is 'GLOBAL'"""
        leave_path = os.path.join(self.data_dir, "leave_requests.json")
        workforce_path = os.path.join(self.data_dir, "workforce.json")
        
        if not os.path.exists(leave_path):
            return {"status": "error", "message": "No leave request data found"}

        with open(leave_path, "r") as f:
            leave_data = json.load(f)
        
        all_requests = leave_data.get("leave_requests", [])
        
        if org_id.upper() == "GLOBAL":
            return {
                "status": "success",
                "org_id": "GLOBAL",
                "total_requests": len(all_requests),
                "leave_requests": all_requests
            }
            
        # Filter by org_id using workforce data
        org_emp_ids = set()
        if os.path.exists(workforce_path):
            with open(workforce_path, "r") as f:
                workforce = json.load(f)
            org_emp_ids = {str(emp["id"]).strip().lower() for emp in workforce if emp.get("org_id", "").lower() == org_id.lower()}
        
        # If no employees found for this org, return empty but success
        org_requests = [r for r in all_requests if str(r.get("emp_id")).strip().lower() in org_emp_ids]
        
        return {
            "status": "success",
            "org_id": org_id,
            "total_requests": len(org_requests),
            "leave_requests": org_requests
        }

    def update_leave_status(self, leave_id: str, status: str):
        """Update the status of a specific leave request with robust ID matching"""
        leave_path = os.path.join(self.data_dir, "leave_requests.json")
        if not os.path.exists(leave_path):
            return {"status": "error", "message": "Leave requests file not found"}
            
        with open(leave_path, "r") as f:
            data = json.load(f)
        
        updated = False
        target_id = str(leave_id).strip().lower()
        
        for req in data.get("leave_requests", []):
            if str(req.get("id")).strip().lower() == target_id:
                req["status"] = status.lower()
                req["approval_date"] = datetime.now().strftime("%Y-%m-%d")
                updated = True
                break
        
        if updated:
            with open(leave_path, "w") as f:
                json.dump(data, f, indent=2)
            return {"status": "success", "message": f"Leave {leave_id} updated to {status}"}
        
        return {"status": "error", "message": f"Leave request ID '{leave_id}' not found in records"}

    def sync_workforce_from_csv(self):
        """Utility to ensure workforce.json matches credentials.csv"""
        csv_path = os.path.join(self.data_dir, "credentials.csv")
        workforce_path = os.path.join(self.data_dir, "workforce.json")
        
        if not os.path.exists(csv_path):
            return {"status": "error", "message": "CSV not found"}
            
        import csv
        new_workforce = []
        with open(csv_path, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["UserType"] == "Employee":
                    # Map CSV fields to Workforce fields
                    new_workforce.append({
                        "id": row["ID"],
                        "name": row["Name"],
                        "status": "Offline",
                        "clock_in": "N/A",
                        "salary": "Pending",
                        "risk": "Low",
                        "department": row.get("Organization", "Unknown"), # We'll use Org as a proxy if dept missing
                        "hours": "0h 0m",
                        "org_id": self._get_org_id_by_name(row["Organization"])
                    })
        
        # Merge with existing logic could go here, but for now we'll prioritize CSV consistency
        with open(workforce_path, "w") as f:
            json.dump(new_workforce, f, indent=4)
        return {"status": "success", "synced": len(new_workforce)}

    def _get_org_id_by_name(self, org_name):
        mapping = {
            "TechCorp Solutions": "ORG-001",
            "InnovateLabs Inc": "ORG-002",
            "GlobalSystems Ltd": "ORG-003",
            "NexusInnova": "ORG-004"
        }
        return mapping.get(org_name, "ORG-000")
    
    # ============= PERFORMANCE METHODS =============
    def get_employee_performance(self, emp_id: str):
        """Get performance data for an employee"""
        perf_path = os.path.join(self.data_dir, "performance.json")
        
        if os.path.exists(perf_path):
            with open(perf_path, "r") as f:
                data = json.load(f)
                records = [r for r in data.get("performance_data", []) if r.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "performance_records": records
                }
        
        return {"status": "error", "message": "No performance data found"}
    
    def get_org_performance(self, org_id: str):
        """Get all performance data for organization"""
        perf_path = os.path.join(self.data_dir, "performance.json")
        
        if os.path.exists(perf_path):
            with open(perf_path, "r") as f:
                data = json.load(f)
                records = data.get("performance_data", [])
                return {
                    "status": "success",
                    "org_id": org_id,
                    "total_employees": len(set(r["emp_id"] for r in records)),
                    "performance_records": records
                }
        
        return {"status": "error", "message": "No performance data found"}
    
    # ============= COMPLAINT METHODS =============
    def submit_complaint(self, emp_id: str, emp_name: str, title: str, description: str):
        """Submit a new complaint"""
        complaints_path = os.path.join(self.data_dir, "complaints.json")
        
        new_complaint = {
            "id": f"complaint-{int(datetime.now().timestamp())}",
            "emp_id": emp_id,
            "emp_name": emp_name,
            "title": title,
            "description": description,
            "status": "submitted",
            "submitted_date": datetime.now().isoformat(),
            "updated_date": datetime.now().isoformat()
        }
        
        # Load existing and add new
        complaints = []
        if os.path.exists(complaints_path):
            with open(complaints_path, "r") as f:
                data = json.load(f)
                complaints = data if isinstance(data, list) else []
        
        complaints.append(new_complaint)
        
        # Save back
        os.makedirs(os.path.dirname(complaints_path), exist_ok=True)
        with open(complaints_path, "w") as f:
            json.dump(complaints, f, indent=2)
        
        return {
            "status": "success",
            "message": "Complaint submitted successfully",
            "complaint": new_complaint
        }
    
    def get_employee_complaints(self, emp_id: str):
        """Get complaints for an employee"""
        complaints_path = os.path.join(self.data_dir, "complaints.json")
        
        if os.path.exists(complaints_path):
            with open(complaints_path, "r") as f:
                data = json.load(f)
                complaints = [c for c in data if isinstance(c, dict) and c.get("emp_id") == emp_id]
                return {
                    "status": "success",
                    "emp_id": emp_id,
                    "complaints": complaints
                }
        
        return {"status": "error", "message": "No complaint data found"}
    
    def get_org_complaints(self, org_id: str):
        """Get all complaints for organization"""
        complaints_path = os.path.join(self.data_dir, "complaints.json")
        
        if os.path.exists(complaints_path):
            with open(complaints_path, "r") as f:
                data = json.load(f)
                complaints = data if isinstance(data, list) else []
                return {
                    "status": "success",
                    "org_id": org_id,
                    "total_complaints": len(complaints),
                    "complaints": complaints
                }
        
        return {"status": "error", "message": "No complaint data found"}

# Global instance
data_service = DataService()
