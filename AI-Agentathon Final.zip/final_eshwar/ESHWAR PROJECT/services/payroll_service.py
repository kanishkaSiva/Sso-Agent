import json
import os
from datetime import datetime
from services.data_service import data_service

class PayrollService:
    def __init__(self):
        self.data_dir = os.path.join(os.getcwd(), "data")
        self.payroll_path = os.path.join(self.data_dir, "payroll_data.json")

    def get_employee_payroll(self, emp_id: str):
        """Fetch payroll history for a specific employee"""
        return data_service.get_employee_payroll(emp_id)

    def get_org_payroll_summary(self, org_id: str):
        """Generate high-level payroll summary and detailed records for the owner dashboard"""
        raw_res = data_service.get_org_payroll(org_id)
        if raw_res["status"] == "error":
            return raw_res
        
        records = raw_res["payroll_records"]
        total_payout = sum(r.get("net_salary", 0) for r in records if r.get("status") == "paid")
        pending_payout = sum(r.get("net_salary", 0) for r in records if r.get("status") == "pending")
        
        return {
            "status": "success",
            "org_id": org_id,
            "total_payout": total_payout,
            "pending_payout": pending_payout,
            "employee_count": len(set(r.get("emp_id") for r in records)),
            "payroll_records": records,
            "last_updated": datetime.now().isoformat()
        }

    def generate_monthly_payroll(self, org_id: str, month: str = None):
        """
        AI-Ready calculation: Generate payroll for all employees in an org
        This would typically sync with Attendance and Performance agents
        """
        if not month:
            month = datetime.now().strftime("%Y-%m")
            
        # 1. Fetch workforce for the org
        workforce_path = os.path.join(self.data_dir, "workforce.json")
        if not os.path.exists(workforce_path):
            return {"status": "error", "message": "Workforce data not found"}
            
        with open(workforce_path, "r") as f:
            workforce = json.load(f)
            
        org_employees = [e for e in workforce if e.get("org_id") == org_id]
        
        # 2. Fetch existing payroll to avoid duplicates for the same month
        existing_data = {"payroll": []}
        if os.path.exists(self.payroll_path):
            with open(self.payroll_path, "r") as f:
                existing_data = json.load(f)
        
        new_records = []
        for emp in org_employees:
            # Check if payroll already exists for this month/emp
            exists = any(r["emp_id"] == emp["id"] and r["month"] == month for r in existing_data["payroll"])
            if exists: continue
            
            # Simulated calculation logic (Logic would be enhanced by security/productivity agents)
            base_salary = emp.get("base_salary", 50000)
            if isinstance(emp.get("salary"), (int, float)):
                base_salary = emp["salary"]
            elif emp.get("salary") == "Pending" or not emp.get("salary"):
                base_salary = 45000 # Default fallback
            
            # Simple simulation: 90-100% attendance
            days_attended = 18 + (hash(emp["id"]) % 5) # Deterministic simulation
            working_days = 22
            
            allowances = base_salary * 0.1
            deductions = (base_salary * 0.05) + ((working_days - days_attended) * (base_salary/working_days))
            net_salary = base_salary + allowances - deductions
            
            record = {
                "emp_id": emp["id"],
                "name": emp["name"],
                "salary": base_salary,
                "month": month,
                "working_days": working_days,
                "days_attended": days_attended,
                "allowances": round(allowances, 2),
                "deductions": round(deductions, 2),
                "net_salary": round(net_salary, 2),
                "status": "pending",
                "payment_date": f"{month}-28"
            }
            new_records.append(record)
            existing_data["payroll"].append(record)
            
        # 3. Save updated payroll
        with open(self.payroll_path, "w") as f:
            json.dump(existing_data, f, indent=4)
            
        return {
            "status": "success",
            "message": f"Generated {len(new_records)} payroll records for {month}",
            "generated_count": len(new_records)
        }

    def process_payment(self, emp_id: str, month: str):
        """Execute payment for a specific record"""
        if not os.path.exists(self.payroll_path):
            return {"status": "error", "message": "No payroll records found"}
            
        with open(self.payroll_path, "r") as f:
            data = json.load(f)
            
        updated = False
        for record in data.get("payroll", []):
            if record["emp_id"] == emp_id and record["month"] == month:
                record["status"] = "paid"
                record["payment_date"] = datetime.now().strftime("%Y-%m-%d")
                updated = True
                break
                
        if updated:
            with open(self.payroll_path, "w") as f:
                json.dump(data, f, indent=4)
            return {"status": "success", "message": f"Payment processed for {emp_id} - {month}"}
            
        return {"status": "error", "message": "Payroll record not found"}

# Global instance
payroll_service = PayrollService()
