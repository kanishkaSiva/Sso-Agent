import random
import json
import os
from datetime import datetime

class ComplaintAgent:
    def __init__(self):
        self.data_path = os.path.join(os.getcwd(), "data", "complaints.json")
        self.complaints = self._load_complaints()

    def _load_complaints(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, "r") as f:
                return json.load(f)
        
        return [
            {"id": "CMP-101", "user": "Anonymous", "issue": "AC not working in cabin 3B", "status": "Logged", "priority": "Low", "sentiment": "Neutral", "date": "2026-02-01"},
            {"id": "CMP-102", "user": "EMP-042", "issue": "Salary delay for January - urgent issue", "status": "Escalated", "priority": "High", "sentiment": "Frustrated", "date": "2026-02-02"},
            {"id": "CMP-103", "user": "EMP-109", "issue": "Request for Work from Home flexibility", "status": "Pending", "priority": "Medium", "sentiment": "Polite", "date": "2026-02-01"}
        ]

    def _save_complaints(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with open(self.data_path, "w") as f:
            json.dump(self.complaints, f, indent=4)

    def _analyze_sentiment(self, text):
        """Analyze sentiment of complaint text"""
        text_lower = text.lower()
        
        # Check for frustrated keywords
        if any(word in text_lower for word in ["angry", "bad", "delay", "worst", "unhappy", "frustrated", "disaster", "terrible"]):
            return "Frustrated"
        
        # Check for positive keywords
        if any(word in text_lower for word in ["please", "request", "helpful", "good", "thank", "appreciate"]):
            return "Positive/Polite"
        
        # Check for neutral/reporting
        if any(word in text_lower for word in ["issue", "problem", "not working", "broken", "need"]):
            return "Concerned"
        
        return "Neutral"

    def process_complaint(self, data: dict):
        """Process and log a new complaint"""
        issue = data.get("issue", "No details provided")
        username = data.get("username", "Anonymous")
        
        # Determine priority based on keywords
        priority = "Low"
        if any(word in issue.lower() for word in ["salary", "payment", "urgent", "critical"]):
            priority = "High"
        elif any(word in issue.lower() for word in ["bug", "crash", "error", "problem"]):
            priority = "Medium"
        
        # Analyze sentiment
        sentiment = self._analyze_sentiment(issue)
        
        new_id = f"CMP-{random.randint(200, 999)}"
        new_complaint = {
            "id": new_id,
            "user": username,
            "issue": issue,
            "status": "AI-Classified",
            "priority": priority,
            "sentiment": sentiment,
            "date": datetime.now().strftime("%Y-%m-%d")
        }
        
        self.complaints.insert(0, new_complaint)
        self._save_complaints()
        
        return {
            "status": "success",
            "complaint_id": new_id,
            "priority": priority,
            "sentiment": sentiment
        }

    def get_all_complaints(self):
        """Get all complaints with stats"""
        return self.complaints
    
    def get_complaint_stats(self):
        """Get complaint statistics"""
        stats = {
            "total": len(self.complaints),
            "high_priority": len([c for c in self.complaints if c["priority"] == "High"]),
            "pending": len([c for c in self.complaints if c["status"] == "Pending"]),
            "frustrated_users": len([c for c in self.complaints if c["sentiment"] == "Frustrated"])
        }
        return stats
    
    def resolve_complaint(self, complaint_id: str):
        """Mark a complaint as resolved"""
        for complaint in self.complaints:
            if complaint["id"] == complaint_id:
                complaint["status"] = "Resolved"
                self._save_complaints()
                return {"status": "success", "message": f"Complaint {complaint_id} resolved"}
        return {"status": "error", "message": "Complaint not found"}
