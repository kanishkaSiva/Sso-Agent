import random
import json
import os
import uuid
from datetime import datetime

class SecurityAgent:
    def __init__(self):
        self.data_path = os.path.join(os.getcwd(), "data", "security_state.json")
        self.org_data_path = os.path.join(os.getcwd(), "data", "organizations.json")
        self.organizations = self._load_organizations()
        # Then load state
        state = self._load_state()
        self.revoked_users = set(state.get("revoked_users", []))
        self.active_sessions = state.get("active_sessions", {})
        self.user_sessions = state.get("user_sessions", {})  # Track sessions per user


    def _load_state(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, "r") as f:
                return json.load(f)
        return {}

    def _load_organizations(self):
        """Load organization data"""
        if os.path.exists(self.org_data_path):
            with open(self.org_data_path, "r") as f:
                data = json.load(f)
                return data.get("organizations", [])
        return []

    def _save_state(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with open(self.data_path, "w") as f:
            json.dump({
                "revoked_users": list(self.revoked_users),
                "active_sessions": self.active_sessions,
                "user_sessions": self.user_sessions
            }, f, indent=4)


    def verify_org_login(self, data: dict):
        """Verify login for organization owner or employee"""
        username = data.get("username", "")
        password = data.get("password", "")
        user_type = data.get("user_type", "employee")  # "owner" or "employee"
        
        # Search through organizations
        for org in self.organizations:
            # Check if owner
            if user_type == "owner" and org["owner"]["username"] == username and org["owner"]["password"] == password:
                session_id = f"SESS-{random.randint(100, 9999)}"
                user_id = org["owner"]["id"]
                
                # Initialize user sessions if not exists
                if user_id not in self.user_sessions:
                    self.user_sessions[user_id] = {"sessions": {}, "total_logins": 0, "org_id": org["org_id"]}
                
                # Create session
                self.user_sessions[user_id]["sessions"][session_id] = {
                    "device": data.get("device", "Unknown Device"),
                    "location": data.get("location", "Unknown Location"),
                    "risk": 0,
                    "status": "Secure",
                    "threat_level": "SECURE",
                    "ip": data.get("ip", "0.0.0.0"),
                    "created": datetime.now().isoformat(),
                    "last_activity": datetime.now().isoformat()
                }
                self.user_sessions[user_id]["total_logins"] += 1
                
                self.active_sessions[session_id] = {
                    "user": org["owner"]["name"],
                    "user_id": user_id,
                    "user_type": "owner",
                    "org_id": org["org_id"],
                    "org_name": org["name"],
                    **self.user_sessions[user_id]["sessions"][session_id]
                }
                
                self._save_state()
                
                return {
                    "status": "allowed",
                    "reason": "Owner Verified",
                    "session_id": session_id,
                    "user_id": user_id,
                    "user_name": org["owner"]["name"],
                    "user_type": "owner",
                    "org_id": org["org_id"],
                    "org_name": org["name"]
                }
            
            # Check if employee
            elif user_type == "employee":
                for emp in org.get("employees", []):
                    if emp["username"] == username and emp["password"] == password:
                        session_id = f"SESS-{random.randint(100, 9999)}"
                        user_id = emp["id"]
                        
                        # Initialize user sessions if not exists
                        if user_id not in self.user_sessions:
                            self.user_sessions[user_id] = {"sessions": {}, "total_logins": 0, "org_id": org["org_id"]}
                        
                        # Create session
                        self.user_sessions[user_id]["sessions"][session_id] = {
                            "device": data.get("device", "Unknown Device"),
                            "location": data.get("location", "Unknown Location"),
                            "risk": 0,
                            "status": "Secure",
                            "threat_level": "SECURE",
                            "ip": data.get("ip", "0.0.0.0"),
                            "created": datetime.now().isoformat(),
                            "last_activity": datetime.now().isoformat()
                        }
                        self.user_sessions[user_id]["total_logins"] += 1
                        
                        self.active_sessions[session_id] = {
                            "user": emp["name"],
                            "user_id": user_id,
                            "user_type": "employee",
                            "org_id": org["org_id"],
                            "org_name": org["name"],
                            "department": emp.get("department", ""),
                            "position": emp.get("position", ""),
                            **self.user_sessions[user_id]["sessions"][session_id]
                        }
                        
                        self._save_state()
                        
                        return {
                            "status": "allowed",
                            "reason": "Employee Verified",
                            "session_id": session_id,
                            "user_id": user_id,
                            "user_name": emp["name"],
                            "user_type": "employee",
                            "org_id": org["org_id"],
                            "org_name": org["name"],
                            "department": emp.get("department", ""),
                            "position": emp.get("position", "")
                        }
        
        return {
            "status": "blocked",
            "reason": "Invalid credentials"
        }

    def get_organization(self, org_id: str):
        """Get organization details"""
        for org in self.organizations:
            if org["org_id"] == org_id:
                return org
        return None

    def get_org_employees(self, org_id: str):
        """Get all employees of an organization"""
        org = self.get_organization(org_id)
        if org:
            return org.get("employees", [])
        return []

    def revoke_access(self, employee_id: str):
        """Revoke employee access (different from session termination)"""
        self.revoked_users.add(employee_id)
        # Force terminate all sessions for this user
        sessions_to_kill = [sid for sid, s in self.active_sessions.items() if s.get("user_id") == employee_id]
        for sid in sessions_to_kill:
            del self.active_sessions[sid]
        
        if employee_id in self.user_sessions:
            self.user_sessions[employee_id]["sessions"] = {}
            
        self._save_state()
        return {"status": "success", "message": f"User {employee_id} terminated globally."}

    def kill_session(self, session_id: str):
        """Terminate a specific session"""
        if session_id in self.active_sessions:
            user = self.active_sessions[session_id]["user"]
            del self.active_sessions[session_id]
            
            # Also remove from user_sessions
            if user in self.user_sessions and session_id in self.user_sessions[user]["sessions"]:
                del self.user_sessions[user]["sessions"][session_id]
            
            self._save_state()
            return {"status": "success", "message": f"Session {session_id} for {user} killed."}
        return {"status": "error", "message": "Session not found."}


    def get_user_sessions(self, user_id: str):
        """Get all sessions for a specific user"""
        if user_id in self.user_sessions:
            sessions = self.user_sessions[user_id].get("sessions", {})
            return {
                "user_id": user_id,
                "active_sessions": len(sessions),
                "sessions": {sid: sess for sid, sess in sessions.items()},
                "total_logins": self.user_sessions[user_id].get("total_logins", 0),
                "first_login": self.user_sessions[user_id].get("first_login")
            }
        return {"user_id": user_id, "active_sessions": 0, "sessions": {}}

    def get_all_sessions(self):
        """AI Risk Recalculation - Get all active sessions with live risk scoring"""
        for sid, s in self.active_sessions.items():
            # Recalculate risk based on location
            if s["location"] != "Chennai, IN":
                s["risk"] = random.randint(80, 99)
                s["status"] = "CRITICAL_RISK"
                s["threat_level"] = "CRITICAL"
            else:
                s["risk"] = random.randint(0, 15)
                s["status"] = "Secure"
                s["threat_level"] = "SECURE"
        
        self._save_state()
        return self.active_sessions
    
    def sync_session_activity(self, session_id: str):
        """Update last activity timestamp for a session"""
        if session_id in self.active_sessions:
            user = self.active_sessions[session_id]["user"]
            if user in self.user_sessions and session_id in self.user_sessions[user]["sessions"]:
                self.user_sessions[user]["sessions"][session_id]["last_activity"] = datetime.now().isoformat()
                self._save_state()
                return {"status": "success"}
        return {"status": "error"}

    # ============= AI-DRIVEN GLOBAL LOGOUT SYSTEM =============
    
    def ai_analyze_session_risk(self, session_id: str):
        """AI analyzes session risk before logout"""
        if session_id not in self.active_sessions:
            return {"risk_score": 0, "threat_level": "UNKNOWN", "analysis": "Session not found"}
        
        session = self.active_sessions[session_id]
        risk_score = session.get("risk", 0)
        location = session.get("location", "Unknown")
        device = session.get("device", "Unknown")
        
        # AI Risk Analysis
        threat_level = "SECURE"
        risk_factors = []
        
        if risk_score > 70:
            threat_level = "CRITICAL"
            risk_factors.append("High risk score detected")
        elif risk_score > 40:
            threat_level = "WARNING"
            risk_factors.append("Moderate risk detected")
        
        if location != "Chennai, IN":
            threat_level = "CRITICAL" if threat_level != "CRITICAL" else threat_level
            risk_factors.append(f"Unusual location: {location}")
        
        if device.lower() in ["unknown", "suspicious"]:
            risk_factors.append("Unrecognized device")
        
        return {
            "session_id": session_id,
            "risk_score": risk_score,
            "threat_level": threat_level,
            "analysis": risk_factors if risk_factors else ["No threats detected"],
            "device": device,
            "location": location,
            "timestamp": datetime.now().isoformat()
        }

    def logout_session(self, session_id: str, user_id: str = None):
        """Logout from a specific session with AI analysis"""
        if session_id not in self.active_sessions:
            return {
                "status": "error",
                "message": "Session not found",
                "session_id": session_id
            }
        
        # AI Risk analysis
        risk_analysis = self.ai_analyze_session_risk(session_id)
        
        # Get user info
        session_data = self.active_sessions[session_id]
        user = session_data.get("user", "Unknown")
        org_id = session_data.get("org_id", "Unknown")
        user_type = session_data.get("user_type", "employee")
        
        # Find user_id if not provided
        if not user_id:
            for uid, user_sess in self.user_sessions.items():
                if session_id in user_sess.get("sessions", {}):
                    user_id = uid
                    break
        
        # Remove session
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
        
        if user_id and user_id in self.user_sessions:
            if session_id in self.user_sessions[user_id]["sessions"]:
                del self.user_sessions[user_id]["sessions"][session_id]
        
        self._save_state()
        
        return {
            "status": "success",
            "message": f"Successfully logged out from session {session_id}",
            "session_id": session_id,
            "user": user,
            "user_id": user_id,
            "user_type": user_type,
            "org_id": org_id,
            "risk_analysis": risk_analysis,
            "logout_timestamp": datetime.now().isoformat()
        }

    def ai_global_logout(self, user_id: str):
        """AI-Driven Global Logout - Terminate ALL sessions for a user"""
        if user_id not in self.user_sessions:
            return {
                "status": "error",
                "message": "User not found",
                "user_id": user_id
            }
        
        user_data = self.user_sessions[user_id]
        sessions = user_data.get("sessions", {})
        session_ids = list(sessions.keys())
        
        logout_results = []
        
        # Analyze all sessions
        for session_id in session_ids:
            risk_analysis = self.ai_analyze_session_risk(session_id)
            
            if session_id in self.active_sessions:
                session_info = self.active_sessions[session_id]
                del self.active_sessions[session_id]
            
            if session_id in sessions:
                del sessions[session_id]
            
            logout_results.append({
                "session_id": session_id,
                "risk_analysis": risk_analysis,
                "status": "terminated"
            })
        
        self._save_state()
        
        # Get user info
        user_name = None
        org_id = None
        user_type = None
        
        # Search in organizations
        for org in self.organizations:
            if org["owner"]["id"] == user_id:
                user_name = org["owner"]["name"]
                org_id = org["org_id"]
                user_type = "owner"
                break
            
            for emp in org.get("employees", []):
                if emp["id"] == user_id:
                    user_name = emp["name"]
                    org_id = org["org_id"]
                    user_type = "employee"
                    break
        
        return {
            "status": "success",
            "message": f"Global logout executed - All {len(session_ids)} sessions terminated",
            "user_id": user_id,
            "user_name": user_name,
            "user_type": user_type,
            "org_id": org_id,
            "sessions_terminated": len(session_ids),
            "session_details": logout_results,
            "logout_timestamp": datetime.now().isoformat()
        }

    def get_user_active_sessions(self, user_id: str):
        """Get all active sessions for a user"""
        if user_id not in self.user_sessions:
            return {
                "status": "error",
                "user_id": user_id,
                "active_sessions": 0,
                "sessions": []
            }
        
        user_data = self.user_sessions[user_id]
        sessions = user_data.get("sessions", {})
        
        session_details = []
        for session_id, session_info in sessions.items():
            # Find full session data from active_sessions
            active_session = self.active_sessions.get(session_id, {})
            risk_analysis = self.ai_analyze_session_risk(session_id)
            
            session_details.append({
                "session_id": session_id,
                "device": session_info.get("device", "Unknown"),
                "location": session_info.get("location", "Unknown"),
                "created": session_info.get("created"),
                "last_activity": session_info.get("last_activity"),
                "risk_score": risk_analysis.get("risk_score", 0),
                "threat_level": risk_analysis.get("threat_level", "UNKNOWN"),
                "ip": session_info.get("ip", "0.0.0.0")
            })
        
        return {
            "status": "success",
            "user_id": user_id,
            "active_sessions_count": len(sessions),
            "total_logins": user_data.get("total_logins", 0),
            "first_login": user_data.get("first_login"),
            "sessions": session_details
        }

    def get_organization_active_sessions(self, org_id: str):
        """Get all active sessions for an organization"""
        org_sessions = []
        
        for session_id, session_data in self.active_sessions.items():
            if session_data.get("org_id") == org_id:
                risk_analysis = self.ai_analyze_session_risk(session_id)
                org_sessions.append({
                    "session_id": session_id,
                    "user": session_data.get("user", "Unknown"),
                    "user_type": session_data.get("user_type", "employee"),
                    "device": session_data.get("device", "Unknown"),
                    "location": session_data.get("location", "Unknown"),
                    "risk_score": risk_analysis.get("risk_score", 0),
                    "threat_level": risk_analysis.get("threat_level", "UNKNOWN"),
                    "created": session_data.get("created"),
                    "last_activity": session_data.get("last_activity")
                })
        
        return {
            "status": "success",
            "org_id": org_id,
            "active_sessions": len(org_sessions),
            "sessions": org_sessions
        }


