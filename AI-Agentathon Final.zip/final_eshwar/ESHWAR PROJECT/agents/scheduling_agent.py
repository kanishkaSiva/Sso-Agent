import random
import json
import os
from datetime import datetime, timedelta

class SchedulingAgent:
    def __init__(self):
        self.data_path = os.path.join(os.getcwd(), "data", "schedule.json")
        self.schedules = self._load_schedule()

    def _load_schedule(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, "r") as f:
                return json.load(f)
        
        return [
            {"id": "SCH-01", "title": "Board Review Meeting", "time": "10:30 AM", "type": "High Priority", "status": "Confirmed", "attendees": 5, "location": "Conference Room A"},
            {"id": "SCH-02", "title": "Q1 Payroll Audit", "time": "02:00 PM", "type": "Internal", "status": "Pending", "attendees": 3, "location": "Finance Department"},
            {"id": "SCH-03", "title": "Growth Strategy Sync", "time": "04:30 PM", "type": "Strategic", "status": "Confirmed", "attendees": 8, "location": "Virtual"},
            {"id": "SCH-04", "title": "Security Server Maintenance", "time": "11:50 PM", "type": "System", "status": "Scheduled", "attendees": 2, "location": "Server Room"}
        ]

    def _save_schedule(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with open(self.data_path, "w") as f:
            json.dump(self.schedules, f, indent=4)

    def get_todays_schedule(self):
        """Fetch the current day's executive schedule"""
        return self.schedules

    def add_event(self, data: dict):
        """Add a new event to the schedule with validation"""
        title = data.get("title", "Unnamed Event")
        time = data.get("time", "TBD")
        event_type = data.get("type", "Standard")
        location = data.get("location", "TBD")
        attendees = data.get("attendees", 1)
        
        new_id = f"SCH-{random.randint(10, 99)}"
        event = {
            "id": new_id,
            "title": title,
            "time": time,
            "type": event_type,
            "status": "Confirmed",
            "attendees": attendees,
            "location": location,
            "created": datetime.now().isoformat()
        }
        
        self.schedules.append(event)
        self._save_schedule()
        
        return {"status": "success", "event": event}

    def optimize_schedule(self):
        """AI Logic: Reorder events for maximum productivity"""
        # Sort by priority - high priority events first
        priority_order = {"High Priority": 0, "Strategic": 1, "Internal": 2, "Standard": 3, "System": 4}
        
        self.schedules.sort(key=lambda x: priority_order.get(x.get("type", "Standard"), 99))
        self._save_schedule()
        
        return {
            "status": "optimized",
            "message": "Schedule optimized for peak owner productivity.",
            "schedule": self.schedules
        }
    
    def get_schedule_conflicts(self):
        """Detect scheduling conflicts"""
        conflicts = []
        for i, event1 in enumerate(self.schedules):
            for event2 in self.schedules[i+1:]:
                if event1["time"] == event2["time"]:
                    conflicts.append({
                        "event1": event1["id"],
                        "event2": event2["id"],
                        "time": event1["time"]
                    })
        return conflicts
    
    def reschedule_event(self, event_id: str, new_time: str):
        """Reschedule an event to a new time"""
        for event in self.schedules:
            if event["id"] == event_id:
                event["time"] = new_time
                self._save_schedule()
                return {"status": "success", "message": f"Event {event_id} rescheduled to {new_time}"}
        return {"status": "error", "message": "Event not found"}
    
    def delete_event(self, event_id: str):
        """Remove an event from the schedule"""
        original_count = len(self.schedules)
        self.schedules = [e for e in self.schedules if e["id"] != event_id]
        
        if len(self.schedules) < original_count:
            self._save_schedule()
            return {"status": "success", "message": f"Event {event_id} deleted from schedule"}
        return {"status": "error", "message": "Event not found"}
