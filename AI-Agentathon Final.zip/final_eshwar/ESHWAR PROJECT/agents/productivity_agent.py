import random
import json
import os
from datetime import datetime

class ProductivityAgent:
    def __init__(self):
        self.data_path = os.path.join(os.getcwd(), "data", "productivity.json")
        self.updates = self._load_updates()

    def _load_updates(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, "r") as f:
                return json.load(f)
        
        return [
            "Frontend Team: Successfully deployed Homepage V3 with 40% performance boost",
            "Backend Team: Database migration for Payroll sync complete - zero downtime",
            "Marketing: Q1 Lead Generation Campaign active - 250+ leads generated",
            "DevOps: Server latency reduced to 45ms - infrastructure optimized",
            "Security: Completed penetration testing - zero critical vulnerabilities found",
            "Product: User engagement metrics up 35% this month"
        ]

    def _save_updates(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with open(self.data_path, "w") as f:
            json.dump(self.updates, f, indent=4)

    def get_live_updates(self, workforce: list = None):
        """Get live team updates reflecting actual workforce activity"""
        dynamic_updates = []
        if workforce:
            active_emps = [e for e in workforce if e.get("status") == "Active"]
            if active_emps:
                emp = random.choice(active_emps)
                dynamic_updates.append(f"⚡ {emp['name']} (${emp['department']}) is currently pushing code for strategic module.")
            
            idle_emps = [e for e in workforce if e.get("status") == "Idle"]
            if idle_emps:
                emp = random.choice(idle_emps)
                dynamic_updates.append(f"☕ {emp['name']} is on a break. Estimated return: 5 mins.")
                
            meetings = [e for e in workforce if e.get("status") == "In Meeting"]
            if meetings:
                emp = random.choice(meetings)
                dynamic_updates.append(f"📅 {emp['name']} is in a high-priority architecture sync.")

        # Always add at least some static updates for density
        static = random.sample(self.updates, 2)
        return dynamic_updates + static

    def track_productivity(self, data: dict):
        """Track productivity for an employee"""
        emp_id = data.get("employee_id", "HARI")
        score = random.randint(75, 98)
        
        return {
            "employee_id": emp_id,
            "score": score,
            "status": "High" if score > 85 else "Good",
            "efficiency": f"{score}%",
            "tasks_completed": random.randint(5, 15),
            "timestamp": datetime.now().isoformat()
        }
    
    def add_update(self, message: str):
        """Add a new update to the feed"""
        self.updates.insert(0, message)
        self._save_updates()
        return {"status": "success", "message": "Update added to feed"}
    
    def get_team_metrics(self):
        """Get team-wide productivity metrics"""
        return {
            "avg_productivity": random.randint(80, 95),
            "on_track_projects": random.randint(8, 12),
            "completed_this_week": random.randint(20, 35),
            "efficiency_rating": "Excellent",
            "trend": "Upward"
        }
    
    def generate_productivity_report(self, time_period: str = "weekly"):
        """Generate productivity report for a time period"""
        return {
            "period": time_period,
            "total_output": f"${random.randint(45, 85)}k",
            "teams_performing_well": ["Engineering", "Product", "Marketing"],
            "areas_to_improve": ["Sales", "Support"],
            "estimated_revenue_impact": f"+{random.randint(5, 15)}%"
        }
