class GrowthAgent:
    def get_historical_performance(self):
        return {
            "labels": ["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8"],
            "actual": [45, 52, 48, 70, 85, 92, 88, 105],
            "target": [40, 45, 50, 60, 75, 80, 85, 90]
        }

    def company_growth(self, workforce_data: list = None):
        # Calculate a dynamic growth rate based on % of active users
        active_count = len([e for e in workforce_data if e.get("status") == "Active"]) if workforce_data else 5
        total_count = len(workforce_data) if workforce_data else 10
        
        ratio = (active_count / total_count) if total_count > 0 else 0.5
        dynamic_mom = 5 + (ratio * 15) # Growth between 5% and 20%
        
        return {
            "productivity_trends": f"{ 'Upward' if ratio > 0.6 else 'Steady' } trajectory ({int(ratio*100)}% active)",
            "mom_growth": f"{dynamic_mom:.1f}%",
            "risk_prediction": "Low turnover risk" if ratio > 0.7 else "Moderate turnover risk",
            "strategy_suggestion": "Expand AI ops" if ratio > 0.8 else "Boost engagement",
            "revenue_projection": f"${2.0 + ratio:.1f}M (Live AI Projection)",
            "wow_factor": "Autonomous Strategy Alignment Active"
        }
