import random
import json
import os
from datetime import datetime, timedelta

class AttendanceAgent:
    def __init__(self):
        self.data_path = os.path.join(os.getcwd(), "data", "workforce.json")
        self.workforce = self._load_data()

    def _load_data(self):
        if os.path.exists(self.data_path):
            with open(self.data_path, "r") as f:
                return json.load(f)
        
        # Enhanced default data with more realistic information
        return [
            {"id": "emp-001", "name": "Rajesh Kumar", "status": "Active", "clock_in": "09:00 AM", "salary": "Credited", "risk": "Low", "department": "Engineering", "hours": "8h 42m"},
            {"id": "emp-002", "name": "Priya Sharma", "status": "In Meeting", "clock_in": "09:15 AM", "salary": "Credited", "risk": "Low", "department": "Marketing", "hours": "7h 30m"},
            {"id": "emp-003", "name": "Amit Singh", "status": "Active", "clock_in": "10:00 AM", "salary": "Pending", "risk": "Medium", "department": "HR", "hours": "6h 15m"},
            {"id": "emp-004", "name": "Neha Verma", "status": "Active", "clock_in": "09:30 AM", "salary": "Credited", "risk": "Low", "department": "Product", "hours": "8h 12m"},
            {"id": "emp-005", "name": "Arjun Nair", "status": "Idle", "clock_in": "11:00 AM", "salary": "Credited", "risk": "Low", "department": "Engineering", "hours": "4h 45m"}
        ]

    def _save_data(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with open(self.data_path, "w") as f:
            json.dump(self.workforce, f, indent=4)

    def get_workforce_status(self, org_id: str = None):
        """Get current workforce status with live updates, optionally filtered by org_id"""
        self.workforce = self._load_data()

        # Simulate real-time status updates for everyone occasionally
        for emp in self.workforce:
            # Randomly change status between Active, Idle, In Meeting for demonstration
            if random.random() < 0.1: # 10% chance to change status
                emp["status"] = random.choice(["Active", "Idle", "In Meeting"])
            
            if emp["status"] == "Active":
                # Increment hours slightly or randomize
                h = random.randint(4, 9)
                m = random.randint(0, 59)
                emp["hours"] = f"{h}h {m}m"
        
        # Filter by org_id if provided (mapping logic: org-001 has emp-001 to emp-003, org-002 has emp-004 to emp-005)
        # For default EMP-10x, we'll assign them to ORG-001 for now
        # Filter by org_id if provided
        if org_id and org_id.upper() != "GLOBAL":
            org_id_lower = org_id.lower()
            return [emp for emp in self.workforce if emp.get("org_id", "").lower() == org_id_lower]
            
        return self.workforce

    def revoke_employee(self, employee_id: str):
        """Remove an employee from the workforce list with logging"""
        original_count = len(self.workforce)
        self.workforce = [e for e in self.workforce if e["id"] != employee_id]
        
        if len(self.workforce) < original_count:
            self._save_data()
            return {
                "status": "success",
                "message": f"Employee {employee_id} revoked and removed from workforce.",
                "timestamp": datetime.now().isoformat()
            }
        return {"status": "error", "message": f"Employee {employee_id} not found."}

    def mark_attendance(self, data: dict):
        """Mark attendance for an employee"""
        emp_id = data.get("employee_id")
        
        for emp in self.workforce:
            if emp["id"] == emp_id:
                emp["clock_in"] = datetime.now().strftime("%I:%M %p")
                emp["status"] = "Active"
                self._save_data()
                return {
                    "status": "present",
                    "employee": emp_id,
                    "timestamp": datetime.now().isoformat(),
                    "message": "Attendance marked successfully"
                }
        
        return {"status": "error", "message": "Employee not found"}
    
    def get_department_stats(self):
        """Get statistics by department"""
        stats = {}
        for emp in self.workforce:
            dept = emp.get("department", "Unknown")
            if dept not in stats:
                stats[dept] = {"total": 0, "active": 0, "idle": 0}
            stats[dept]["total"] += 1
            if emp["status"] == "Active":
                stats[dept]["active"] += 1
            elif emp["status"] == "Idle":
                stats[dept]["idle"] += 1
        return stats
