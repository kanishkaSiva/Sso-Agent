from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from orchestrator.agent_router import (
    org_login_flow,
    complaint_flow,
    dashboard_flow,
    logout_flow,
    global_logout_flow,
    growth_agent,
    scheduling_agent,
    attendance_agent,
    security_agent,
    payroll_agent,
    productivity_agent
)
from services.data_service import data_service
from services.payroll_service import payroll_service
import json

app = FastAPI(title="Agentic Enterprise Platform - Multi-Portal")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# MAIN LANDING PAGE - DUAL PORTAL SELECTION
# ============================================================================

@app.get("/", response_class=HTMLResponse)
def landing_page():
    """Main landing page with dual portal selection"""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AGENTIC OS - Enterprise Portal</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg: #121212;
                --card-bg: #1a1a1a;
                --accent: #3b82f6; 
                --accent-cyan: #00d4ff;
                --gold: #facc15;
                --text: #eeeeee;
                --glass: rgba(255, 255, 255, 0.03);
            }

            /* Emerald Matrix Theme */
            [data-theme="emerald"] {
                --bg: #09130f;
                --card-bg: #0d1a14;
                --accent: #10b981;
                --accent-cyan: #34d399;
                --gold: #facc15;
                --text: #ecfdf5;
            }

            /* Midnight Security (Red) */
            [data-theme="midnight"] {
                --bg: #1a0b0b;
                --card-bg: #2d1616;
                --accent: #ef4444;
                --accent-cyan: #f87171;
                --gold: #f59e0b;
                --text: #fef2f2;
            }

            /* Hyper Space (Purple) */
            [data-theme="purple"] {
                --bg: #0f0720;
                --card-bg: #1a0d35;
                --accent: #8b5cf6;
                --accent-cyan: #a78bfa;
                --gold: #fbbf24;
                --text: #f5f3ff;
            }

            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }
            body { 
                background: var(--bg);
                background-image: radial-gradient(circle at center, rgba(255,255,255,0.02) 0%, transparent 100%);
                color: var(--text); 
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
                padding: 20px;
                transition: background 0.5s ease;
            }
            .container {
                text-align: center;
                max-width: 1000px;
            }
            
            /* Theme Switcher */
            .theme-panel {
                position: fixed;
                top: 2rem;
                right: 2rem;
                background: var(--card-bg);
                padding: 8px;
                border-radius: 50px;
                display: flex;
                gap: 8px;
                border: 1px solid var(--glass);
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 1000;
            }
            .theme-dot {
                width: 24px;
                height: 24px;
                border-radius: 50%;
                cursor: pointer;
                border: 2px solid transparent;
                transition: transform 0.2s;
            }
            .theme-dot:hover { transform: scale(1.2); }
            .theme-dot.active { border-color: #fff; transform: scale(1.1); }

            .header {
                margin-bottom: 4rem;
                animation: slideInDown 0.8s ease-out;
            }
            .header h1 {
                font-size: 3.5rem;
                margin-bottom: 1rem;
                letter-spacing: -2px;
            }
            .header h1 span { color: var(--accent-cyan); text-shadow: 0 0 30px var(--accent); }
            .header p {
                font-size: 1.2rem;
                color: #888;
                margin-bottom: 1rem;
            }
            
            .portals-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                gap: 3rem;
                margin-top: 3rem;
            }
            
            .portal-card {
                background: var(--card-bg);
                padding: 3rem;
                border-radius: 24px;
                border: 1px solid var(--glass);
                cursor: pointer;
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                position: relative;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                animation: slideInUp 0.8s ease-out;
            }
            
            .portal-card:hover {
                transform: translateY(-15px);
                border-color: var(--accent-cyan);
                box-shadow: 0 20px 50px rgba(0,0,0,0.5), 0 0 20px var(--accent);
            }
            
            .portal-card.owner {
                border-color: var(--gold);
            }
            
            .portal-card.owner:hover {
                border-color: var(--gold);
                box-shadow: 0 20px 50px rgba(0,0,0,0.5), 0 0 20px rgba(250, 204, 21, 0.3);
            }
            
            .icon { font-size: 4rem; margin-bottom: 2rem; }
            
            .portal-card h2 {
                font-size: 2rem;
                margin-bottom: 1rem;
                color: var(--accent);
            }
            
            .portal-card.owner h2 {
                color: var(--gold);
            }
            
            .portal-card p {
                color: #888;
                font-size: 0.95rem;
                margin-bottom: 2.5rem;
                line-height: 1.6;
            }
            
            .btn {
                padding: 1rem 2rem;
                border: none;
                border-radius: 12px;
                font-weight: 700;
                cursor: pointer;
                transition: all 0.3s;
                text-transform: uppercase;
                letter-spacing: 1px;
                font-size: 1rem;
                width: 100%;
            }
            
            .btn-user {
                background: var(--accent);
                color: white;
            }
            
            .btn-user:hover {
                filter: brightness(1.2); transform: scale(1.02);
            }
            
            .btn-owner {
                background: var(--gold);
                color: #000;
            }
            
            .btn-owner:hover {
                filter: brightness(1.2); transform: scale(1.02);
            }
            
            @keyframes slideInDown {
                from {
                    opacity: 0;
                    transform: translateY(-50px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes slideInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .footer {
                margin-top: 4rem;
                color: #555;
                font-size: 0.9rem;
            }
        </style>
    </head>
    <body data-theme="default">
        <div class="theme-panel">
            <div class="theme-dot" style="background:#3b82f6" onclick="setTheme('default')" title="Agentic Blue"></div>
            <div class="theme-dot" style="background:#10b981" onclick="setTheme('emerald')" title="Matrix Green"></div>
            <div class="theme-dot" style="background:#ef4444" onclick="setTheme('midnight')" title="Security Red"></div>
            <div class="theme-dot" style="background:#8b5cf6" onclick="setTheme('purple')" title="Hyper Purple"></div>
        </div>

        <div class="container">
            <div class="header">
                <h1><span>AGENTIC</span> OS</h1>
                <p>Intelligent Enterprise Workforce Management Platform</p>
                <div style="margin-top: 1rem; color: var(--accent-cyan); font-size: 0.9rem; letter-spacing: 1px; font-weight: 500;">
                    AI-DRIVEN MULTI-SESSION SINGLE LOGIN • FORCED GLOBAL LOGOUT SECURED
                </div>
            </div>
            
            <div class="portals-grid">
                <!-- Employee Portal -->
                <div class="portal-card" onclick="window.location.href='/employee/login'">
                    <div class="icon">👥</div>
                    <h2>Employee Portal</h2>
                    <p>Access your personal dashboard, track attendance, manage your identity across multiple devices, and execute global security logout.</p>
                    <button class="btn btn-user">Login as Employee</button>
                    <div style="margin-top: 1.5rem; font-size: 0.75rem; color: var(--accent); opacity: 0.7;">
                        🛡️ Multi-Session Logic Enabled
                    </div>
                </div>
                
                <!-- Owner/Manager Portal -->
                <div class="portal-card owner" onclick="window.location.href='/owner/login'">
                    <div class="icon">👑</div>
                    <h2>Owner Portal</h2>
                    <p>Oversee organization security, monitor AI-driven session risk in real-time, and perform administrative forced global logouts.</p>
                    <button class="btn btn-owner">Login as Owner</button>
                    <div style="margin-top: 1.5rem; font-size: 0.75rem; color: var(--gold); opacity: 0.7;">
                        👁️ AI Identity Guardian Active
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <p>© 2025 AGENTIC OS. All rights reserved. | Secure Enterprise Solutions</p>
            </div>
        </div>

        <script>
            function setTheme(theme) {
                document.body.setAttribute('data-theme', theme);
                localStorage.setItem('agentic_theme', theme);
                
                document.querySelectorAll('.theme-dot').forEach(dot => {
                    dot.classList.remove('active');
                    if(dot.title.toLowerCase().includes(theme === 'default' ? 'blue' : theme)) {
                        dot.classList.add('active');
                    }
                });
            }

            // Restore theme
            const savedTheme = localStorage.getItem('agentic_theme') || 'default';
            setTheme(savedTheme);
        </script>
    </body>
    </html>
    """
    return html_content

# ============================================================================
# EMPLOYEE LOGIN & DASHBOARD
# ============================================================================

@app.get("/employee/login", response_class=HTMLResponse)
def employee_login_page():
    """Employee login page"""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Login - AGENTIC OS</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg: #121212;
                --card-bg: #1a1a1a;
                --accent: #3b82f6;
                --accent-cyan: #00d4ff;
                --text: #eeeeee;
                --glass: rgba(255, 255, 255, 0.03);
            }
            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }
            body {
                background: radial-gradient(circle at center, #111 0%, #000 100%);
                color: var(--text);
                height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
            }
            .login-container {
                width: 100%;
                max-width: 450px;
                background: var(--card-bg);
                padding: 3rem;
                border-radius: 24px;
                border: 1px solid var(--glass);
                box-shadow: 0 0 50px rgba(59, 130, 246, 0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 2rem;
            }
            .header h1 {
                font-size: 1.8rem;
                margin-bottom: 0.5rem;
            }
            .header p {
                color: #888;
                font-size: 0.95rem;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            label {
                display: block;
                font-size: 0.7rem;
                color: #666;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 8px;
            }
            input {
                width: 100%;
                background: #000;
                border: 1px solid #222;
                padding: 12px;
                border-radius: 12px;
                color: white;
                outline: none;
                transition: 0.3s;
            }
            input:focus {
                border-color: var(--accent);
                box-shadow: 0 0 20px rgba(59, 130, 246, 0.2);
            }
            .btn-login {
                width: 100%;
                padding: 14px;
                background: linear-gradient(135deg, var(--accent), var(--accent-cyan));
                color: white;
                border: none;
                border-radius: 12px;
                font-weight: 700;
                cursor: pointer;
                text-transform: uppercase;
                letter-spacing: 1px;
                transition: 0.3s;
                margin-top: 1.5rem;
            }
            .btn-login:hover {
                transform: scale(1.02);
                box-shadow: 0 0 30px rgba(59, 130, 246, 0.4);
            }
            .info-box {
                background: rgba(59, 130, 246, 0.1);
                border-left: 3px solid var(--accent);
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                font-size: 0.85rem;
                line-height: 1.5;
            }
            .back-link {
                text-align: center;
                margin-top: 1.5rem;
            }
            .back-link a {
                color: var(--accent);
                text-decoration: none;
                font-size: 0.9rem;
                transition: 0.3s;
            }
            .back-link a:hover {
                text-decoration: underline;
            }
            .error { color: #ff4444; font-size: 0.85rem; margin-top: 0.5rem; }
            .success { color: #00ff88; font-size: 0.85rem; margin-top: 0.5rem; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>👥 Employee Portal</h1>
                <p>Login to your workspace</p>
            </div>
            
            <div class="info-box">
                <strong>Demo Credentials:</strong><br>
                Username: rajesh_kumar | Pass: pass123<br>
                Or: priya_sharma | Pass: pass123<br>
                Or: amit_singh | Pass: pass123
            </div>
            
            <form id="loginForm">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                
                <button type="submit" class="btn-login">Login</button>
                <div id="message"></div>
            </form>
            
            <div class="back-link">
                <a href="/">← Back to Portal Selection</a>
            </div>
        </div>
        
        <script>
            document.getElementById('loginForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                const messageDiv = document.getElementById('message');
                
                try {
                    const response = await fetch('/api/employee/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            username,
                            password,
                            user_type: 'employee',
                            device: 'Web Browser',
                            location: 'Chennai, IN'
                        })
                    });
                    
                    const data = await response.json();
                    if (data.status === 'allowed') {
                        sessionStorage.setItem('session_id', data.session_id);
                        sessionStorage.setItem('user_id', data.user_id);
                        sessionStorage.setItem('user_name', data.user_name);
                        sessionStorage.setItem('org_id', data.org_id);
                        sessionStorage.setItem('user_type', 'employee');
                        messageDiv.innerHTML = '<p class="success">Login successful! Redirecting...</p>';
                        setTimeout(() => window.location.href = '/employee/dashboard', 1500);
                    } else {
                        messageDiv.innerHTML = '<p class="error">' + data.reason + '</p>';
                    }
                } catch (err) {
                    messageDiv.innerHTML = '<p class="error">Login failed. Please try again.</p>';
                }
            });
        </script>
    </body>
    </html>
    """
    return html_content

@app.post("/api/employee/login")
async def employee_login(request: Request):
    """Employee login API with agent sync"""
    data = await request.json()
    result = org_login_flow(data)
    return result

@app.get("/employee/dashboard", response_class=HTMLResponse)
def employee_dashboard():
    """Interactive employee dashboard with logout functionality"""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Dashboard - AGENTIC OS</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg: #121212;
                --card-bg: #1a1a1a;
                --accent: #3b82f6;
                --accent-cyan: #00d4ff;
                --success: #00ff88;
                --warning: #ff9500;
                --danger: #ff4444;
                --text: #eeeeee;
            }

            /* Emerald Matrix Theme */
            [data-theme="emerald"] {
                --bg: #09130f;
                --card-bg: #0d1a14;
                --accent: #10b981;
                --accent-cyan: #34d399;
                --text: #ecfdf5;
            }

            /* Midnight Security (Red) */
            [data-theme="midnight"] {
                --bg: #1a0b0b;
                --card-bg: #2d1616;
                --accent: #ef4444;
                --accent-cyan: #f87171;
                --text: #fef2f2;
            }

            /* Hyper Space (Purple) */
            [data-theme="purple"] {
                --bg: #0f0720;
                --card-bg: #1a0d35;
                --accent: #8b5cf6;
                --accent-cyan: #a78bfa;
                --text: #f5f3ff;
            }

            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }
            body {
                background: var(--bg);
                background-image: radial-gradient(circle at center, rgba(255,255,255,0.02) 0%, transparent 100%);
                color: var(--text);
                min-height: 100vh;
                padding: 20px;
                transition: background 0.5s ease;
            }
            .dashboard-container {
                max-width: 1400px;
                margin: 0 auto;
            }

            /* Theme Switcher */
            .theme-panel {
                background: var(--card-bg);
                padding: 6px;
                border-radius: 50px;
                display: flex;
                gap: 8px;
                border: 1px solid #333;
                align-items: center;
            }
            .theme-dot {
                width: 20px;
                height: 20px;
                border-radius: 50%;
                cursor: pointer;
                border: 2px solid transparent;
                transition: transform 0.2s;
            }
            .theme-dot:hover { transform: scale(1.2); }
            .theme-dot.active { border-color: #fff; transform: scale(1.1); }

            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 3rem;
                flex-wrap: wrap;
                gap: 1rem;
            }
            .header h1 {
                font-size: 2.5rem;
            }
            .header-right {
                display: flex;
                gap: 1.5rem;
                flex-wrap: wrap;
                align-items: center;
            }
            .sync-indicator {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 0.75rem;
                color: #888;
                background: rgba(255, 255, 255, 0.05);
                padding: 6px 12px;
                border-radius: 20px;
                border: 1px solid #333;
            }
            .sync-dot {
                width: 8px;
                height: 8px;
                background: var(--success);
                border-radius: 50%;
                box-shadow: 0 0 10px var(--success);
                animation: pulse-green 2s infinite;
            }
            @keyframes pulse-green {
                0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0.7); }
                70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(0, 255, 136, 0); }
                100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0); }
            }
            .user-info {
                background: var(--card-bg);
                padding: 1.5rem;
                border-radius: 12px;
                border: 1px solid #222;
            }
            .session-counter {
                background: rgba(59, 130, 246, 0.1);
                padding: 1rem;
                border-radius: 8px;
                font-size: 0.9rem;
                border-left: 3px solid var(--accent);
            }
            .btn-group {
                display: flex;
                gap: 0.5rem;
            }
            .btn {
                padding: 10px 20px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                transition: 0.3s;
                font-weight: 600;
                text-transform: uppercase;
                font-size: 0.85rem;
            }
            .btn-logout {
                background: var(--danger);
                color: white;
            }
            .btn-logout:hover {
                transform: scale(1.05);
                box-shadow: 0 0 20px rgba(255, 68, 68, 0.3);
            }
            .btn-sessions {
                background: var(--accent);
                color: white;
            }
            .btn-sessions:hover {
                transform: scale(1.05);
                box-shadow: 0 0 20px rgba(59, 130, 246, 0.3);
            }
            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 2rem;
                margin-bottom: 3rem;
            }
            .card {
                background: var(--card-bg);
                padding: 2rem;
                border-radius: 16px;
                border: 1px solid #222;
                transition: all 0.3s;
                cursor: pointer;
            }
            .card:hover {
                border-color: var(--accent);
                transform: translateY(-5px);
                box-shadow: 0 0 40px rgba(59, 130, 246, 0.1);
            }
            .card h2 {
                font-size: 1.3rem;
                margin-bottom: 0.5rem;
            }
            .card p {
                color: #888;
                font-size: 0.9rem;
            }
            .stat-card {
                background: var(--card-bg);
                padding: 1.5rem;
                border-radius: 16px;
                border-left: 4px solid var(--accent);
                margin-bottom: 1.5rem;
            }
            .stat-label {
                color: #888;
                font-size: 0.85rem;
                margin-bottom: 0.5rem;
            }
            .stat-value {
                font-size: 2rem;
                font-weight: 700;
                color: var(--accent);
            }
            .modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.7);
                z-index: 1000;
                align-items: center;
                justify-content: center;
            }
            .modal-content {
                background: var(--card-bg);
                padding: 2rem;
                border-radius: 16px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
            }
            .close-modal {
                float: right;
                cursor: pointer;
                font-size: 2rem;
                color: #888;
            }
            .sessions-list {
                margin-top: 1.5rem;
            }
            .session-item {
                background: #000;
                padding: 1.5rem;
                border-radius: 8px;
                border: 1px solid #222;
                margin-bottom: 1rem;
            }
            .session-item h4 {
                color: var(--accent);
                margin-bottom: 0.5rem;
            }
            .session-info {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
                margin-bottom: 1rem;
                font-size: 0.9rem;
            }
            .session-info-item {
                color: #888;
            }
            .session-risk {
                padding: 0.5rem 1rem;
                border-radius: 8px;
                font-weight: 600;
                display: inline-block;
            }
            .risk-secure {
                background: rgba(0, 255, 136, 0.2);
                color: var(--success);
            }
            .risk-warning {
                background: rgba(255, 149, 0, 0.2);
                color: var(--warning);
            }
            .risk-critical {
                background: rgba(255, 68, 68, 0.2);
                color: var(--danger);
            }
        </style>
    </head>
    <body>
        <div class="dashboard-container">
            <div class="header">
                <div>
                    <h1>👥 Employee Dashboard</h1>
                    <p style="color: #888; margin-top: 0.5rem;">Welcome, <span id="userName"></span></p>
                </div>
                <div class="header-right">
                    <div class="theme-panel">
                        <div class="theme-dot" style="background:#3b82f6" onclick="setTheme('default')" title="Agentic Blue"></div>
                        <div class="theme-dot" style="background:#10b981" onclick="setTheme('emerald')" title="Matrix Green"></div>
                        <div class="theme-dot" style="background:#ef4444" onclick="setTheme('midnight')" title="Security Red"></div>
                        <div class="theme-dot" style="background:#8b5cf6" onclick="setTheme('purple')" title="Hyper Purple"></div>
                    </div>
                    <div class="sync-indicator">
                        <div class="sync-dot"></div>
                        <span id="syncText">SYNCING...</span>
                    </div>
                    <div class="user-info">
                        <p><strong>Org:</strong> <span id="orgName" style="color: var(--accent);">-</span></p>
                    </div>
                    <div class="session-counter" id="sessionCounter">
                        Active Sessions: <strong>-</strong>
                    </div>
                    <div class="btn-group">
                        <button class="btn btn-sessions" onclick="viewSessions()">View Sessions</button>
                        <button class="btn btn-logout" onclick="logoutConfirm()">Logout</button>
                    </div>
                </div>
            </div>
            
            <div class="grid">
                <div class="card" onclick="openModule('attendance', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">📅</div>
                    <h2>Attendance</h2>
                    <p id="attendanceText">View your attendance record and history</p>
                </div>
                <div class="card" onclick="openModule('schedule', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">🗓️</div>
                    <h2>Work Schedule</h2>
                    <p>Check your upcoming shifts and assignments</p>
                </div>
                <div class="card" onclick="openModule('payroll', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">💰</div>
                    <h2>Payroll</h2>
                    <p>View salary information and payment history</p>
                </div>
                <div class="card" onclick="openModule('complaint', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">📝</div>
                    <h2>File Complaint</h2>
                    <p>Report issues or concerns to management</p>
                </div>
                <div class="card" onclick="openModule('performance', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">📊</div>
                    <h2>Performance</h2>
                    <p>Track your productivity and performance metrics</p>
                </div>
                <div class="card" onclick="openModule('leave', event)">
                    <div style="font-size: 2.5rem; margin-bottom: 1rem;">📋</div>
                    <h2>Leave Requests</h2>
                    <p>Submit or track leave requests</p>
                </div>
            </div>
            
            <h2 style="margin: 2rem 0 1rem 0;">Quick Stats</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                <div class="stat-card">
                    <div class="stat-label">Attendance Rate</div>
                    <div class="stat-value" id="quickAttendanceRate">...</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Productivity Score</div>
                    <div class="stat-value" id="quickProductivity">...</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Pending Requests</div>
                    <div class="stat-value" id="quickPending">...</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Next Payment</div>
                    <div class="stat-value" id="quickPayment">...</div>
                </div>
            </div>
        </div>
        
        <!-- Sessions Modal -->
        <div id="sessionsModal" class="modal" onclick="closeModal(event, 'sessions')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'sessions')">&times;</span>
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                    <div style="font-size: 2rem;">🛡️</div>
                    <div>
                        <h2 style="margin: 0;">AI Identity Guardian</h2>
                        <p style="color: var(--accent-cyan); font-size: 0.8rem; margin: 0;">MULTI-SESSION AGENTIC MONITORING ACTIVE</p>
                    </div>
                </div>
                <div id="aiSecurityInsights" style="background: rgba(59, 130, 246, 0.1); border-left: 3px solid var(--accent); padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.85rem; display: none;">
                    <strong>AI SECURITY INSIGHTS:</strong> <span id="securityInsightText">Analyzing your active sessions...</span>
                </div>
                <div class="sessions-list" id="sessionsList">Loading...</div>
            </div>
        </div>
        
        <!-- Attendance Modal -->
        <div id="attendanceModal" class="modal" onclick="closeModal(event, 'attendance')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'attendance')">&times;</span>
                <h2>📅 Attendance Records</h2>
                <div id="attendanceContent" style="margin-top: 1.5rem;">Loading...</div>
            </div>
        </div>
        
        <!-- Schedule Modal -->
        <div id="scheduleModal" class="modal" onclick="closeModal(event, 'schedule')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'schedule')">&times;</span>
                <h2>🗓️ Work Schedule</h2>
                <div id="scheduleContent" style="margin-top: 1.5rem;">Loading...</div>
            </div>
        </div>
        
        <!-- Payroll Modal -->
        <div id="payrollModal" class="modal" onclick="closeModal(event, 'payroll')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'payroll')">&times;</span>
                <h2>💰 Payroll Details</h2>
                <div id="payrollContent" style="margin-top: 1.5rem;">Loading...</div>
            </div>
        </div>
        
        <!-- Complaint Modal -->
        <div id="complaintModal" class="modal" onclick="closeModal(event, 'complaint')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'complaint')">&times;</span>
                <h2>📝 File A Complaint</h2>
                <form id="complaintForm" style="margin-top: 1.5rem;">
                    <div style="margin-bottom: 1rem;">
                        <label style="color: #666; font-size: 0.85rem;">Title:</label>
                        <input type="text" id="complaintTitle" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white;">
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label style="color: #666; font-size: 0.85rem;">Description:</label>
                        <textarea id="complaintDesc" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white; min-height: 120px;"></textarea>
                    </div>
                    <button type="submit" style="padding: 10px 20px; background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer;">Submit Complaint</button>
                </form>
            </div>
        </div>
        
        <!-- Performance Modal -->
        <div id="performanceModal" class="modal" onclick="closeModal(event, 'performance')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'performance')">&times;</span>
                <h2>📊 Performance Metrics</h2>
                <div id="performanceContent" style="margin-top: 1.5rem;">Loading...</div>
            </div>
        </div>
        
        <!-- Leave Modal -->
        <div id="leaveModal" class="modal" onclick="closeModal(event, 'leave')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'leave')">&times;</span>
                <h2>📋 Leave Requests</h2>
                <div id="leaveContent" style="margin-top: 1.5rem;">Loading...</div>
            </div>
        </div>
        
        <!-- Logout Confirm Modal -->
        <div id="logoutModal" class="modal" onclick="closeModal(event, 'logout')">
            <div class="modal-content" onclick="event.stopPropagation()" style="max-width: 400px;">
                <h2>🔓 Logout Options</h2>
                <p style="color: #888; margin: 1.5rem 0;">Choose how you'd like to logout:</p>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <button class="btn" style="background: var(--accent); color: white; padding: 12px; text-align: center;" onclick="logoutCurrentSession()">
                        Logout from This Session
                    </button>
                    <button class="btn" style="background: var(--danger); color: white; padding: 12px; text-align: center;" onclick="globalLogout()">
                        Global Logout (All Sessions)
                    </button>
                    <button class="btn" style="background: #555; color: white; padding: 12px; text-align: center;" onclick="closeModal(null, 'logout')">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
        
        <script>
            const userId = sessionStorage.getItem('user_id');
            
            async function initDashboard() {
                const userName = sessionStorage.getItem('user_name');
                const orgName = sessionStorage.getItem('org_id');
                
                if (!userName) {
                    window.location.href = '/employee/login';
                    return;
                }
                
                document.getElementById('userName').textContent = userName;
                document.getElementById('orgName').textContent = orgName || 'Your Organization';
                
                await refreshEmployeeDashboard();
                setInterval(refreshEmployeeDashboard, 15000); // Pulse every 15s
            }

            async function refreshEmployeeDashboard() {
                const syncText = document.getElementById('syncText');
                if (syncText) syncText.textContent = 'SYNCING...';
                
                try {
                    await loadActiveSessions(userId);
                    
                    // Update Quick Stats
                    const perfRes = await fetch(`/api/performance/employee/${userId}`);
                    const perfData = await perfRes.json();
                    if (perfData.status === 'success' && perfData.performance_records.length > 0) {
                        document.getElementById('quickProductivity').textContent = perfData.performance_records[0].productivity_score + '/10';
                    }

                    const leaveRes = await fetch(`/api/leave/employee/${userId}`);
                    const leaveData = await leaveRes.json();
                    if (leaveData.status === 'success') {
                        const pending = leaveData.leave_requests.filter(l => l.status === 'pending').length;
                        document.getElementById('quickPending').textContent = pending;
                    }
                    
                    // Simulate dynamic updates for "Real Time" feel
                    const randAtt = 94 + (Math.random() * 4);
                    document.getElementById('quickAttendanceRate').textContent = randAtt.toFixed(1) + '%';
                    
                    const nextPay = 4 - (new Date().getDate() % 5);
                    document.getElementById('quickPayment').textContent = (nextPay > 0 ? nextPay : 30 + nextPay) + ' days';

                    if (syncText) syncText.textContent = 'LIVE';
                } catch (err) {
                    if (syncText) syncText.textContent = 'OFFLINE';
                }
            }
            
            async function openModule(module, event) {
                event.preventDefault();
                const modalId = module + 'Modal';
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.style.display = 'flex';
                    await loadModuleData(module);
                }
            }
            
            async function loadModuleData(module) {
                try {
                    if (module === 'attendance') {
                        const res = await fetch(`/api/attendance/employee/${userId}`);
                        const data = await res.json();
                        const content = document.getElementById('attendanceContent');
                        if (data.status === 'success') {
                            let html = `<p style="color: #888; margin-bottom: 1rem;">Total Records: <strong>${data.total_records}</strong></p>`;
                            data.records.forEach(r => {
                                html += `<div style="background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #222;">
                                    <p><strong>${r.date}</strong> - ${r.status.toUpperCase()}</p>
                                    <p style="color: #888; font-size: 0.9rem;">Check-in: ${r.check_in} | Check-out: ${r.check_out} | Duration: ${r.duration}</p>
                                </div>`;
                            });
                            content.innerHTML = html;
                        }
                    } else if (module === 'schedule') {
                        const res = await fetch(`/api/schedule/employee/${userId}`);
                        const data = await res.json();
                        const content = document.getElementById('scheduleContent');
                        if (data.status === 'success') {
                            let html = `<p style="color: #888; margin-bottom: 1rem;">Upcoming Schedules: <strong>${data.schedules.length}</strong></p>`;
                            data.schedules.forEach(s => {
                                html += `<div style="background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #222;">
                                    <p><strong>${s.date}</strong> - ${s.shift}</p>
                                    <p style="color: #888; font-size: 0.9rem;">📍 ${s.location}</p>
                                    <p style="color: var(--accent); font-size: 0.9rem;">Project: ${s.project}</p>
                                    <p style="font-size: 0.85rem;">Tasks: ${s.tasks.join(', ')}</p>
                                </div>`;
                            });
                            content.innerHTML = html;
                        }
                    } else if (module === 'payroll') {
                        const res = await fetch(`/api/payroll/employee/${userId}`);
                        const data = await res.json();
                        const content = document.getElementById('payrollContent');
                        if (data.status === 'success') {
                            let html = '';
                            data.payroll_records.forEach(p => {
                                html += `<div style="background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border-left: 3px solid var(--accent);">
                                    <p><strong>${p.month}</strong> | Status: <span style="color: ${p.status === 'paid' ? 'var(--success)' : 'var(--warning)'};">${p.status.toUpperCase()}</span></p>
                                    <table style="width: 100%; margin-top: 0.5rem; font-size: 0.9rem; color: #888;">
                                        <tr><td>Basic Salary:</td><td style="text-align: right;">₹${p.salary}</td></tr>
                                        <tr><td>Allowances:</td><td style="text-align: right;">₹${p.allowances}</td></tr>
                                        <tr><td>Deductions:</td><td style="text-align: right;">-₹${p.deductions}</td></tr>
                                        <tr style="border-top: 1px solid #333; color: var(--accent); font-weight: 600;"><td>Net Salary:</td><td style="text-align: right;">₹${p.net_salary}</td></tr>
                                    </table>
                                    <p style="font-size: 0.8rem; color: #666; margin-top: 0.5rem;">Payment: ${p.payment_date}</p>
                                </div>`;
                            });
                            content.innerHTML = html;
                        }
                    } else if (module === 'performance') {
                        const res = await fetch(`/api/performance/employee/${userId}`);
                        const data = await res.json();
                        const content = document.getElementById('performanceContent');
                        if (data.status === 'success') {
                            let html = '';
                            data.performance_records.forEach(p => {
                                html += `<div style="background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #222;">
                                    <p><strong>${p.month}</strong></p>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin: 0.5rem 0; font-size: 0.9rem;">
                                        <div>Productivity: <span style="color: var(--success);">${p.productivity_score}/10</span></div>
                                        <div>Quality: <span style="color: var(--success);">${p.quality_score}/10</span></div>
                                        <div>Collaboration: <span style="color: var(--success);">${p.collaboration_score}/10</span></div>
                                        <div>Punctuality: <span style="color: var(--success);">${p.punctuality_score}/10</span></div>
                                    </div>
                                    <p style="font-size: 0.85rem; color: #888; margin-top: 0.5rem;">Tasks: ${p.tasks_completed} completed, ${p.tasks_pending} pending</p>
                                    <p style="font-size: 0.85rem; color: #aaa; margin-top: 0.5rem; font-style: italic;">💭 "${p.feedback}"</p>
                                </div>`;
                            });
                            content.innerHTML = html;
                        }
                    } else if (module === 'leave') {
                        const res = await fetch(`/api/leave/employee/${userId}`);
                        const data = await res.json();
                        const content = document.getElementById('leaveContent');
                        let html = `<button style="width: 100%; padding: 10px; background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer; margin-bottom: 1rem;" onclick="toggleLeaveForm()">+ New Leave Request</button>
                        <div id="leaveForm" style="display: none; background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #333;">
                            <div style="margin-bottom: 0.5rem;">
                                <label style="color: #666; font-size: 0.85rem;">Leave Type:</label>
                                <select id="leaveType" style="width: 100%; padding: 8px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white;">
                                    <option>Casual Leave</option>
                                    <option>Sick Leave</option>
                                    <option>Earned Leave</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 0.5rem;">
                                <label style="color: #666; font-size: 0.85rem;">Start Date:</label>
                                <input type="date" id="leaveStart" required style="width: 100%; padding: 8px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white;">
                            </div>
                            <div style="margin-bottom: 0.5rem;">
                                <label style="color: #666; font-size: 0.85rem;">End Date:</label>
                                <input type="date" id="leaveEnd" required style="width: 100%; padding: 8px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white;">
                            </div>
                            <div style="margin-bottom: 0.5rem;">
                                <label style="color: #666; font-size: 0.85rem;">Reason:</label>
                                <textarea id="leaveReason" required style="width: 100%; padding: 8px; margin-top: 5px; border-radius: 8px; border: 1px solid #333; background: #000; color: white; min-height: 60px;"></textarea>
                            </div>
                            <button onclick="submitLeaveRequest()" style="width: 100%; padding: 10px; background: var(--accent); color: white; border: none; border-radius: 8px; cursor: pointer;">Submit Leave Request</button>
                        </div>`;
                        if (data.status === 'success') {
                            data.leave_requests.forEach(l => {
                                const statusColor = l.status === 'approved' ? 'var(--success)' : l.status === 'pending' ? 'var(--warning)' : 'var(--danger)';
                                html += `<div style="background: #000; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border-left: 3px solid ${statusColor};">
                                    <p><strong>${l.leave_type}</strong> | ${l.start_date} to ${l.end_date} (<strong>${l.duration}</strong> days)</p>
                                    <p style="color: #888; font-size: 0.9rem;">Status: <span style="color: ${statusColor};">${l.status.toUpperCase()}</span></p>
                                    <p style="font-size: 0.85rem; color: #aaa;">Reason: ${l.reason}</p>
                                </div>`;
                            });
                        }
                        content.innerHTML = html;
                    }
                } catch (err) {
                    console.error('Error loading module:', err);
                }
            }
            
            function toggleLeaveForm() {
                const form = document.getElementById('leaveForm');
                form.style.display = form.style.display === 'none' ? 'block' : 'none';
            }
            
            async function submitLeaveRequest() {
                const startDate = document.getElementById('leaveStart').value;
                const endDate = document.getElementById('leaveEnd').value;
                const leaveType = document.getElementById('leaveType').value;
                const reason = document.getElementById('leaveReason').value;
                const userName = sessionStorage.getItem('user_name');
                
                if (!startDate || !endDate) {
                    alert('Please select BOTH dates');
                    return;
                }
                const startYear = new Date(startDate).getFullYear();
                if (startYear < 2025 || startYear > 2027) {
                    alert('Invalid date range selected');
                    return;
                }

                try {
                    const res = await fetch('/api/leave/submit', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            emp_id: userId,
                            emp_name: userName,
                            leave_type: leaveType,
                            start_date: startDate,
                            end_date: endDate,
                            reason: reason
                        })
                    });
                    
                    if (res.ok) {
                        alert('Leave request submitted successfully!');
                        await loadModuleData('leave');
                    }
                } catch (err) {
                    alert('Error submitting leave request');
                }
            }
            
            async function loadActiveSessions(userId) {
                try {
                    const response = await fetch(`/api/sessions/user/${userId}`);
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        document.getElementById('sessionCounter').innerHTML = 
                            `Active Sessions: <strong>${data.active_sessions_count}</strong>`;
                    }
                } catch (err) {
                    console.error('Error loading sessions:', err);
                }
            }
            
            function viewSessions() {
                document.getElementById('sessionsModal').style.display = 'flex';
                loadSessionsList();
            }
            
            async function loadSessionsList() {
                try {
                    const response = await fetch(`/api/sessions/user/${userId}`);
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        const sessionsList = document.getElementById('sessionsList');
                        const insightsDiv = document.getElementById('aiSecurityInsights');
                        const insightText = document.getElementById('securityInsightText');
                        
                        sessionsList.innerHTML = `
                            <p style="color: #888; margin-bottom: 1.5rem;">
                                Identity Agent detected <strong>${data.active_sessions_count}</strong> authenticated access points.
                            </p>
                        `;
                        
                        // AI Insight Generation Logic
                        if (insightsDiv && insightText) {
                            insightsDiv.style.display = 'block';
                            if (data.active_sessions_count > 3) {
                                insightText.textContent = "High number of concurrent sessions detected. Agent recommends a Global Logout if you're finished with your shift.";
                                insightsDiv.style.borderLeftColor = 'var(--warning)';
                            } else if (data.sessions.some(s => s.threat_level !== 'SECURE')) {
                                insightText.textContent = "Potential threat detected in an active session. Security Agent suggests immediate termination of suspicious links.";
                                insightsDiv.style.borderLeftColor = 'var(--danger)';
                            } else {
                                insightText.textContent = "All sessions verified. Agentic identity shielding is maintaining a 99.9% security score across all devices.";
                                insightsDiv.style.borderLeftColor = 'var(--success)';
                            }
                        }
                        
                        data.sessions.forEach(session => {
                            const riskClass = session.threat_level === 'SECURE' ? 'risk-secure' : 
                                            session.threat_level === 'WARNING' ? 'risk-warning' : 'risk-critical';
                            
                            const html = `
                                <div class="session-item">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                                        <h4 style="margin: 0;">${session.device}</h4>
                                        <div style="font-size: 0.65rem; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px; color: #666;">
                                            ID: ${session.session_id}
                                        </div>
                                    </div>
                                    <div class="session-info">
                                        <div class="session-info-item"><strong>Location:</strong> ${session.location}</div>
                                        <div class="session-info-item"><strong>IP:</strong> ${session.ip}</div>
                                        <div class="session-info-item"><strong>Threat Logic:</strong> <span class="session-risk ${riskClass}">${session.threat_level}</span></div>
                                        <div class="session-info-item"><strong>Risk Score:</strong> ${session.risk_score}%</div>
                                    </div>
                                    <div style="margin: 1rem 0; padding: 0.8rem; background: rgba(0,0,0,0.3); border-radius: 8px; font-size: 0.8rem; border-left: 2px solid var(--accent-cyan);">
                                        <span style="color: var(--accent-cyan); font-weight: 600;">AGENT LOG:</span> 
                                        ${session.threat_level === 'SECURE' ? 'Verified via cryptopattern sync.' : 'Mismatched location signature detected.'}
                                    </div>
                                    <button class="btn" style="background: var(--danger); color: white; width: 100%; padding: 8px; font-size: 0.75rem;" 
                                            onclick="logoutSpecificSession('${session.session_id}')">
                                        PURGE SESSION
                                    </button>
                                </div>
                            `;
                            document.getElementById('sessionsList').innerHTML += html;
                        });
                    }
                } catch (err) {
                    document.getElementById('sessionsList').innerHTML = '<p style="color: #ff4444;">Failed to load sessions</p>';
                }
            }
            
            function logoutConfirm() {
                document.getElementById('logoutModal').style.display = 'flex';
            }
            
            async function logoutCurrentSession() {
                const sessionId = sessionStorage.getItem('session_id');
                
                try {
                    const response = await fetch(`/api/logout/session/${sessionId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: userId })
                    });
                    
                    const data = await response.json();
                    if (data.status === 'success') {
                        sessionStorage.clear();
                        window.location.href = '/employee/login';
                    }
                } catch (err) {
                    console.error('Logout failed:', err);
                }
            }
            
            async function logoutSpecificSession(sessionId) {
                try {
                    const response = await fetch(`/api/logout/session/${sessionId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: userId })
                    });
                    
                    const data = await response.json();
                    if (data.status === 'success') {
                        alert('Session logged out successfully');
                        await initDashboard();
                        await loadSessionsList();
                    }
                } catch (err) {
                    console.error('Logout failed:', err);
                }
            }
            
            async function globalLogout() {
                if (!confirm('Are you sure? This will logout from ALL sessions!')) return;
                
                try {
                    const response = await fetch(`/api/logout/global/${userId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });
                    
                    const data = await response.json();
                    if (data.status === 'success') {
                        sessionStorage.clear();
                        window.location.href = '/employee/login';
                    }
                } catch (err) {
                    console.error('Global logout failed:', err);
                }
            }
            
            function closeModal(event, modalType) {
                if (event && event.target.id !== modalType + 'Modal') return;
                const modal = document.getElementById(modalType + 'Modal');
                if (modal) {
                    modal.style.display = 'none';
                }
            }

            // Complaint Form Submission
            if (document.getElementById('complaintForm')) {
                document.getElementById('complaintForm').addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const title = document.getElementById('complaintTitle').value;
                    const description = document.getElementById('complaintDesc').value;
                    const userName = sessionStorage.getItem('user_name');
                    const orgId = sessionStorage.getItem('org_id');
                    
                    try {
                        const res = await fetch('/api/complaint/submit', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                username: userName, // Agent expects 'username'
                                issue: title + ': ' + description, // Agent expects 'issue'
                                emp_id: userId,
                                org_id: orgId,
                                title: title,
                                description: description
                            })
                        });
                        
                        if (res.ok) {
                            alert('Complaint filed! AGENTIC OS AI is analyzing your issue.');
                            document.getElementById('complaintForm').reset();
                            closeModal(null, 'complaint');
                        }
                    } catch (err) {
                        alert('Error filing complaint');
                    }
                });
            }
            
            function setTheme(theme) {
                document.body.setAttribute('data-theme', theme);
                localStorage.setItem('agentic_theme', theme);
                
                document.querySelectorAll('.theme-dot').forEach(dot => {
                    dot.classList.remove('active');
                    if(dot.title.toLowerCase().includes(theme === 'default' ? 'blue' : theme)) {
                        dot.classList.add('active');
                    }
                });
            }

            // Restore theme
            const savedTheme = localStorage.getItem('agentic_theme') || 'default';
            setTheme(savedTheme);
            
            document.addEventListener('DOMContentLoaded', initDashboard);
        </script>
    </body>
    </html>
    """
    return html_content

# ============================================================================
# OWNER LOGIN & DASHBOARD
# ============================================================================

@app.get("/owner/login", response_class=HTMLResponse)
def owner_login_page():
    """Owner login page"""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Owner Login - AGENTIC OS</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg: #121212;
                --card-bg: #1a1a1a;
                --accent: #facc15;
                --accent-dark: #f59e0b;
                --text: #eeeeee;
                --glass: rgba(255, 255, 255, 0.03);
            }
            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }
            body {
                background: radial-gradient(circle at center, #111 0%, #000 100%);
                color: var(--text);
                height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
            }
            .login-container {
                width: 100%;
                max-width: 450px;
                background: var(--card-bg);
                padding: 3rem;
                border-radius: 24px;
                border: 1px solid var(--accent);
                box-shadow: 0 0 50px rgba(250, 204, 21, 0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 2rem;
            }
            .header h1 {
                font-size: 1.8rem;
                color: var(--accent);
            }
            .header p {
                color: #888;
                font-size: 0.95rem;
                margin-top: 0.5rem;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            label {
                display: block;
                font-size: 0.7rem;
                color: #666;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 8px;
            }
            input {
                width: 100%;
                background: #000;
                border: 1px solid #222;
                padding: 12px;
                border-radius: 12px;
                color: white;
                outline: none;
                transition: 0.3s;
            }
            input:focus {
                border-color: var(--accent);
                box-shadow: 0 0 20px rgba(250, 204, 21, 0.2);
            }
            .btn-login {
                width: 100%;
                padding: 14px;
                background: linear-gradient(135deg, var(--accent), var(--accent-dark));
                color: #000;
                border: none;
                border-radius: 12px;
                font-weight: 700;
                cursor: pointer;
                text-transform: uppercase;
                letter-spacing: 1px;
                transition: 0.3s;
                margin-top: 1.5rem;
            }
            .btn-login:hover {
                transform: scale(1.02);
                box-shadow: 0 0 30px rgba(250, 204, 21, 0.4);
            }
            .info-box {
                background: rgba(250, 204, 21, 0.1);
                border-left: 3px solid var(--accent);
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                font-size: 0.85rem;
                line-height: 1.5;
            }
            .back-link {
                text-align: center;
                margin-top: 1.5rem;
            }
            .back-link a {
                color: var(--accent);
                text-decoration: none;
                font-size: 0.9rem;
                transition: 0.3s;
            }
            .back-link a:hover {
                text-decoration: underline;
            }
            .error { color: #ff4444; font-size: 0.85rem; margin-top: 0.5rem; }
            .success { color: #00ff88; font-size: 0.85rem; margin-top: 0.5rem; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>👑 Owner Portal</h1>
                <p>Login to manage your organization</p>
            </div>
            
            <div class="info-box">
                <strong>Demo Credentials:</strong><br>
                Username: hari_tech | Pass: admin123<br>
                Or: vikram_patel | Pass: secure456
            </div>
            
            <form id="loginForm">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                
                <button type="submit" class="btn-login">Login</button>
                <div id="message"></div>
            </form>
            
            <div class="back-link">
                <a href="/">← Back to Portal Selection</a>
            </div>
        </div>
        
        <script>
            document.getElementById('loginForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                const messageDiv = document.getElementById('message');
                
                try {
                    const response = await fetch('/api/owner/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            username,
                            password,
                            user_type: 'owner',
                            device: 'Web Browser',
                            location: 'Chennai, IN'
                        })
                    });
                    
                    const data = await response.json();
                    if (data.status === 'allowed') {
                        sessionStorage.setItem('session_id', data.session_id);
                        sessionStorage.setItem('user_id', data.user_id);
                        sessionStorage.setItem('user_name', data.user_name);
                        sessionStorage.setItem('org_id', data.org_id);
                        sessionStorage.setItem('org_name', data.org_name);
                        sessionStorage.setItem('user_type', 'owner');
                        messageDiv.innerHTML = '<p class="success">Login successful! Redirecting...</p>';
                        setTimeout(() => window.location.href = '/owner/dashboard', 1500);
                    } else {
                        messageDiv.innerHTML = '<p class="error">' + data.reason + '</p>';
                    }
                } catch (err) {
                    messageDiv.innerHTML = '<p class="error">Login failed. Please try again.</p>';
                }
            });
        </script>
    </body>
    </html>
    """
    return html_content

@app.post("/api/owner/login")
async def owner_login(request: Request):
    """Owner login API with agent sync"""
    data = await request.json()
    result = org_login_flow(data)
    return result

@app.get("/owner/dashboard", response_class=HTMLResponse)
def owner_dashboard():
    """Interactive owner dashboard with AI alerts, session monitoring, and performance tracking"""
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Owner Dashboard - AGENTIC OS</title>
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg: #0a0e27;
                --card-bg: #151932;
                --accent: #00d4ff;
                --accent-warm: #facc15;
                --success: #00ff88;
                --warning: #ff9500;
                --danger: #ff4444;
                --text: #e0e0e0;
            }

            /* Emerald Matrix Theme */
            [data-theme="emerald"] {
                --bg: #09130f;
                --card-bg: #0d1a14;
                --accent: #10b981;
                --accent-warm: #facc15;
                --text: #ecfdf5;
            }

            /* Midnight Security (Red) */
            [data-theme="midnight"] {
                --bg: #1a0b0b;
                --card-bg: #2d1616;
                --accent: #ef4444;
                --accent-warm: #f59e0b;
                --text: #fef2f2;
            }

            /* Hyper Space (Purple) */
            [data-theme="purple"] {
                --bg: #0f0720;
                --card-bg: #1a0d35;
                --accent: #8b5cf6;
                --accent-warm: #fbbf24;
                --text: #f5f3ff;
            }

            * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Space Grotesk', sans-serif; }
            body {
                background: var(--bg);
                background-image: radial-gradient(circle at center, rgba(255,255,255,0.02) 0%, transparent 100%);
                color: var(--text);
                min-height: 100vh;
                padding: 20px;
                transition: background 0.5s ease;
            }
            .dashboard-container {
                max-width: 1600px;
                margin: 0 auto;
            }

            /* Theme Switcher */
            .theme-panel {
                background: var(--card-bg);
                padding: 6px;
                border-radius: 50px;
                display: flex;
                gap: 8px;
                border: 1px solid #333;
                align-items: center;
            }
            .theme-dot {
                width: 20px;
                height: 20px;
                border-radius: 50%;
                cursor: pointer;
                border: 2px solid transparent;
                transition: transform 0.2s;
            }
            .theme-dot:hover { transform: scale(1.2); }
            .theme-dot.active { border-color: #fff; transform: scale(1.1); }
            /* AI ALERT BANNER */
            .ai-alert {
                background: linear-gradient(135deg, rgba(255, 68, 68, 0.15), rgba(255, 149, 0, 0.15));
                border: 1px solid #ff6b6b;
                border-radius: 12px;
                padding: 1.5rem;
                margin-bottom: 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 1rem;
            }
            .alert-text {
                display: flex;
                align-items: center;
                gap: 1rem;
            }
            .alert-text strong {
                font-size: 1.1rem;
            }
            .btn-alert {
                background: var(--accent);
                color: #000;
                padding: 10px 20px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 700;
            }
            .btn-alert:hover {
                transform: scale(1.05);
            }
            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                gap: 1rem;
            }
            .header h1 {
                font-size: 2.2rem;
                background: linear-gradient(135deg, var(--accent), var(--accent-warm));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }
            .header-right {
                display: flex;
                gap: 1rem;
                flex-wrap: wrap;
                align-items: center;
            }
            .sync-indicator {
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 0.75rem;
                color: #888;
                background: rgba(0, 0, 0, 0.3);
                padding: 5px 12px;
                border-radius: 20px;
                border: 1px solid #333;
            }
            .sync-dot {
                width: 8px;
                height: 8px;
                background: var(--success);
                border-radius: 50%;
                box-shadow: 0 0 10px var(--success);
                animation: pulse-green 2s infinite;
            }
            @keyframes pulse-green {
                0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0.7); }
                70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(0, 255, 136, 0); }
                100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0); }
            }
            .header-right button {
                padding: 10px 20px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 600;
                text-transform: uppercase;
                font-size: 0.75rem;
            }
            .btn-sessions { background: var(--accent); color: #000; }
            .btn-logout { background: var(--danger); color: white; }
            .btn-sessions:hover, .btn-logout:hover { transform: scale(1.05); }
            
            /* STAT CARDS */
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }
            .stat-card {
                background: var(--card-bg);
                padding: 1.5rem;
                border-radius: 12px;
                border: 1px solid #222;
            }
            .stat-label {
                color: #888;
                font-size: 0.75rem;
                text-transform: uppercase;
                margin-bottom: 0.5rem;
            }
            .stat-value {
                font-size: 2rem;
                font-weight: 700;
                color: var(--accent);
            }
            
            /* MAIN GRID */
            .main-grid {
                display: grid;
                grid-template-columns: 2fr 1fr;
                gap: 2rem;
                margin-bottom: 2rem;
            }
            
            .card {
                background: var(--card-bg);
                padding: 1.5rem;
                border-radius: 12px;
                border: 1px solid #222;
                transition: all 0.3s;
                cursor: pointer;
            }
            .card:hover {
                border-color: var(--accent);
                transform: translateY(-3px);
                box-shadow: 0 0 30px rgba(0, 212, 255, 0.1);
            }
            .card h3 {
                margin-bottom: 1rem;
                color: var(--accent);
            }
            
            .feature-cards {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 1rem;
            }
            .feature-card {
                background: #000;
                padding: 1.5rem;
                border-radius: 12px;
                border: 1px solid #222;
                text-align: center;
                cursor: pointer;
                transition: 0.3s;
            }
            .feature-card:hover {
                border-color: var(--accent);
                transform: translateY(-3px);
            }
            .feature-card-icon {
                font-size: 2rem;
                margin-bottom: 0.5rem;
            }
            .feature-card-text {
                font-size: 0.85rem;
                color: #999;
            }
            
            .sessions-container {
                max-height: 300px;
                overflow-y: auto;
            }
            .session-item {
                background: #000;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1rem;
                border: 1px solid #222;
            }
            .session-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 0.5rem;
            }
            .session-user {
                font-weight: 600;
                color: var(--accent);
            }
            .session-risk {
                padding: 3px 10px;
                border-radius: 6px;
                font-size: 0.75rem;
                font-weight: 600;
            }
            .risk-secure { background: rgba(0, 255, 136, 0.2); color: var(--success); }
            .risk-warning { background: rgba(255, 149, 0, 0.2); color: var(--warning); }
            .risk-critical { background: rgba(255, 68, 68, 0.2); color: var(--danger); }
            
            .employee-perf {
                background: #000;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1rem;
                border-left: 3px solid var(--accent);
                cursor: pointer;
                transition: 0.3s;
            }
            .employee-perf:hover {
                transform: translateX(5px);
            }
            .emp-name {
                font-weight: 600;
                color: var(--text);
                margin-bottom: 0.25rem;
            }
            .emp-score {
                display: flex;
                gap: 1rem;
                font-size: 0.85rem;
                color: #888;
            }
            .score-item {
                display: flex;
                align-items: center;
                gap: 0.25rem;
            }
            .score-value {
                color: var(--success);
                font-weight: 600;
            }
            
            /* MODAL */
            .modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                z-index: 1000;
                align-items: center;
                justify-content: center;
            }
            .modal-content {
                background: var(--card-bg);
                padding: 2rem;
                border-radius: 16px;
                max-width: 700px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                border: 1px solid #222;
            }
            .close-modal {
                float: right;
                cursor: pointer;
                font-size: 2rem;
                color: #888;
            }
            .modal h2 { color: var(--accent); margin-bottom: 1.5rem; }
            
            .btn-action {
                padding: 10px 20px;
                background: var(--danger);
                color: white;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                margin-top: 0.5rem;
                font-size: 0.85rem;
                width: 100%;
            }
            .btn-action:hover { transform: scale(1.02); }
            
            .badge {
                position: absolute;
                top: -8px;
                right: -8px;
                background: var(--danger);
                color: white;
                font-size: 0.7rem;
                padding: 2px 6px;
                border-radius: 10px;
                font-weight: 700;
                box-shadow: 0 0 10px rgba(255, 68, 68, 0.5);
                display: none;
            }
            .feature-card { position: relative; }
            
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes fadeOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        </style>
    </head>
    <body>
        <div class="dashboard-container">
            <!-- AI ALERT BANNER -->
            <div class="ai-alert" id="aiAlert" style="display: none;">
                <div class="alert-text">
                    <span style="font-size: 1.5rem;">⚠️</span>
                    <div>
                        <strong id="alertTitle">AI ALERT: High Risk Session Detected</strong>
                        <div id="alertDetail" style="color: #ccc; font-size: 0.9rem; margin-top: 0.25rem;"></div>
                    </div>
                </div>
                <button class="btn-alert" onclick="blockSession()">BLOCK & REVOKE</button>
            </div>
            
            <!-- HEADER -->
            <div class="header">
                <div>
                    <h1>👑 <span id="orgNameBanner"></span> OWNER COMMAND</h1>
                    <p style="color: #888; margin-top: 0.5rem;">Welcome, <strong id="userName"></strong></p>
                </div>
                <div class="header-right">
                    <div class="theme-panel">
                        <div class="theme-dot" style="background:#3b82f6" onclick="setTheme('default')" title="Agentic Blue"></div>
                        <div class="theme-dot" style="background:#10b981" onclick="setTheme('emerald')" title="Matrix Green"></div>
                        <div class="theme-dot" style="background:#ef4444" onclick="setTheme('midnight')" title="Security Red"></div>
                        <div class="theme-dot" style="background:#8b5cf6" onclick="setTheme('purple')" title="Hyper Purple"></div>
                    </div>
                    <div class="sync-indicator">
                        <div class="sync-dot"></div>
                        <span id="syncText">SYNCING...</span>
                    </div>
                    <div style="font-size: 0.8rem; color: #666; margin-right: 1rem;">LAST SYNC: <span id="lastUpdate">--:--:--</span></div>
                    <button class="btn-sessions" onclick="viewOrgSessions()">👥 SESSIONS</button>
                    <button class="btn-sessions" onclick="viewComplaints()">📋 COMPLAINTS</button>
                    <button class="btn-logout" onclick="logoutConfirm()">LOGOUT</button>
                </div>
            </div>
            
            <!-- STATS -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label">Active Users</div>
                    <div class="stat-value" id="activeUsers">0</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Finance Risk</div>
                    <div class="stat-value" style="color: var(--success);" id="financeRisk">12%</div>
                    <div style="font-size: 0.75rem; color: #888;">(Low)</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Security Score</div>
                    <div class="stat-value" style="color: var(--success);" id="securityScore">98%</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">MoM Growth</div>
                    <div class="stat-value" style="color: var(--success);">12.4%</div>
                </div>
            </div>
            
            <!-- MAIN CONTENT -->
            <div class="main-grid">
                <!-- LEFT SECTION -->
                <div>
                    <!-- WORKFORCE TRACKING -->
                    <div class="card">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                            <h3>📊 WORKFORCE TRACKING SYSTEM</h3>
                            <button class="btn-sessions" id="toggleGlobalView" style="width: auto; padding: 5px 15px; font-size: 0.8rem; background: #222;" onclick="toggleGlobalWorkforce()">GLOBAL VIEW: OFF</button>
                        </div>
                        <table style="width: 100%; font-size: 0.85rem;">
                            <tr style="color: #888; border-bottom: 1px solid #222; padding-bottom: 0.5rem;">
                                <td style="padding: 0.5rem 0;">NAME</td>
                                <td style="padding: 0.5rem 0;">STATUS</td>
                                <td style="padding: 0.5rem 0;">CLOCK-IN</td>
                                <td style="padding: 0.5rem 0;">CONTROL</td>
                            </tr>
                            <tbody id="workforceTable"></tbody>
                        </table>
                    </div>
                    
                    <!-- REVENUE ANALYTICS -->
                    <div class="card" style="margin-top: 1.5rem;">
                        <h3>💹 REVENUE ANALYTICS</h3>
                        <div style="text-align: center; padding: 2rem 0; color: #888;">
                            <div style="font-size: 0.9rem; margin-bottom: 1rem;">Monthly Revenue Trend</div>
                            <div style="color: var(--accent); font-size: 1.5rem; font-weight: 700;" id="revenueGrowth">↗ +12.4% MoM</div>
                            <div style="font-size: 0.85rem; color: #666; margin-top: 0.5rem;">AI-Predicted Revenue: <span id="revenueProjection" style="color: #bbb;">$2.8M</span></div>
                        </div>
                    </div>
                </div>
                
                <!-- RIGHT SECTION -->
                <div>
                    <!-- EXECUTIVE SCHEDULE -->
                    <div class="card">
                        <h3>📅 EXECUTIVE SCHEDULE</h3>
                        <div id="executiveSchedule" style="max-height: 250px; overflow-y: auto;"></div>
                        <button class="btn-sessions" onclick="addEvent()" style="width: 100%; margin-top: 1rem;">➕ ADD EVENT</button>
                    </div>
                    
                    <!-- LIVE TEAM UPDATES -->
                    <div class="card" style="margin-top: 1.5rem;">
                        <h3>⚡ LIVE TEAM UPDATES</h3>
                        <div id="liveUpdates" style="max-height: 150px; overflow-y: auto; font-size: 0.9rem;">
                            <div style="color: #555; padding: 1rem; text-align: center;">Waiting for live updates...</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- IDENTITY GUARDIAN & SESSIONS -->
            <div class="main-grid" style="margin-top: 2rem;">
                <div class="card">
                    <h3>🔐 IDENTITY GUARDIAN - LIVE SESSION AUDIT</h3>
                    <div class="sessions-container" id="sessionAudit">Loading...</div>
                </div>
                
                <div class="card">
                    <h3>📈 EMPLOYEE PERFORMANCE</h3>
                    <div id="employeePerformance" style="max-height: 300px; overflow-y: auto;"></div>
                </div>
            </div>
            
            <!-- FEATURES -->
            <h3 style="margin: 2rem 0 1rem; color: var(--accent);">MANAGEMENT FEATURES</h3>
            <div class="feature-cards">
                <div class="feature-card" onclick="manageEmployees()">
                    <div class="feature-card-icon">👥</div>
                    <div class="feature-card-text">Manage Employees</div>
                </div>
                <div class="feature-card" onclick="viewAttendance()">
                    <div class="feature-card-icon">📊</div>
                    <div class="feature-card-text">View Attendance</div>
                </div>
                <div class="feature-card" onclick="viewPayroll()">
                    <div class="feature-card-icon">💰</div>
                    <div class="feature-card-text">Payroll Management</div>
                </div>
                <div class="feature-card" onclick="viewLeaveRequests()">
                    <div class="badge" id="leaveBadge">0</div>
                    <div class="feature-card-icon">📋</div>
                    <div class="feature-card-text">Leave Approvals</div>
                </div>
                <div class="feature-card" onclick="viewComplaints()">
                    <div class="badge" id="complaintBadge">0</div>
                    <div class="feature-card-icon">📝</div>
                    <div class="feature-card-text">View Complaints</div>
                </div>
                <div class="feature-card" onclick="viewPerformance()">
                    <div class="feature-card-icon">📈</div>
                    <div class="feature-card-text">Performance Data</div>
                </div>
            </div>
        </div>
        
        <!-- MODALS -->
        <div id="sessionsModal" class="modal" onclick="closeModal(event, 'sessions')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'sessions')">&times;</span>
                <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                    <div style="font-size: 2rem;">🛡️</div>
                    <div>
                        <h2 style="margin: 0;">Organization Identity Guardian</h2>
                        <p style="color: var(--accent); font-size: 0.8rem; margin: 0;">AI-DRIVEN REAL-TIME SESSION MONITORING</p>
                    </div>
                </div>
                <div style="background: rgba(250, 204, 21, 0.1); border-left: 3px solid var(--accent-warm); padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; font-size: 0.85rem;">
                    <strong>ADMIN SECURITY LOG:</strong> Monitoring all active entry points. AI is scanning for credential leakage and session hijacking.
                </div>
                <div id="sessionsList" style="max-height: 400px; overflow-y: auto;"></div>
            </div>
        </div>
        
        <div id="complaintsModal" class="modal" onclick="closeModal(event, 'complaints')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'complaints')">&times;</span>
                <h2>📋 Employee Complaints & AI Sentiment</h2>
                <div id="complaintsList" style="max-height: 450px; overflow-y: auto; margin-top: 1rem;"></div>
            </div>
        </div>

        <!-- NEW INTERACTIVE MODALS -->
        <div id="manageEmployeesModal" class="modal" onclick="closeModal(event, 'manageEmployees')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'manageEmployees')">&times;</span>
                <h2>👥 Manage Global Workforce</h2>
                <p style="color: #666; font-size: 0.9rem; margin-bottom: 1.5rem;">Total employees registered in organization</p>
                <div id="manageEmployeesList" style="max-height: 450px; overflow-y: auto;"></div>
            </div>
        </div>

        <div id="attendanceModal" class="modal" onclick="closeModal(event, 'attendance')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'attendance')">&times;</span>
                <h2>📊 Detailed Attendance Audit</h2>
                <p style="color: #666; font-size: 0.9rem; margin-bottom: 1.5rem;">Live tracking of clock-in and working hours</p>
                <div id="attendanceLogs" style="max-height: 450px; overflow-y: auto;"></div>
            </div>
        </div>

        <div id="payrollModal" class="modal" onclick="closeModal(event, 'payroll')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'payroll')">&times;</span>
                <h2>💰 Payroll Management System</h2>
                <p style="color: #666; font-size: 0.9rem; margin-bottom: 1.5rem;">Salary statuses and disbursement tracking</p>
                <div id="payrollList" style="max-height: 450px; overflow-y: auto;"></div>
            </div>
        </div>

        <div id="leaveApprovalsModal" class="modal" onclick="closeModal(event, 'leaveApprovals')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <span class="close-modal" onclick="closeModal(null, 'leaveApprovals')">&times;</span>
                <h2>📋 Leave Requests & Approvals</h2>
                <p style="color: #666; font-size: 0.9rem; margin-bottom: 1.5rem;">Review and manage employee leave applications</p>
                <div id="leaveRequestsList" style="max-height: 450px; overflow-y: auto;"></div>
            </div>
        </div>

        <div id="addEventModal" class="modal" onclick="closeModal(event, 'addEvent')">
            <div class="modal-content" onclick="event.stopPropagation()" style="max-width: 450px;">
                <span class="close-modal" onclick="closeModal(null, 'addEvent')">&times;</span>
                <h2>➕ Add Executive Event</h2>
                <form id="eventForm" style="margin-top: 1.5rem;">
                    <div style="margin-bottom: 1rem;">
                        <label>Title</label>
                        <input type="text" id="eventTitle" placeholder="e.g. Sales Strategy Meeting" required style="width:100%; padding:12px; margin-top:5px; border-radius:8px; border:1px solid #333; background:#000; color:white;">
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label>Time</label>
                        <input type="text" id="eventTime" placeholder="e.g. 10:30 AM" required style="width:100%; padding:12px; margin-top:5px; border-radius:8px; border:1px solid #333; background:#000; color:white;">
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label>Category</label>
                        <select id="eventCategory" style="width:100%; padding:12px; margin-top:5px; border-radius:8px; border:1px solid #333; background:#000; color:white;">
                            <option>High Priority</option>
                            <option>Strategic</option>
                            <option>Internal</option>
                            <option>System</option>
                        </select>
                    </div>
                    <button type="submit" style="width:100%; padding:14px; background:var(--accent); color:#000; border:none; border-radius:8px; cursor:pointer; font-weight:700;">SCHEDULE EVENT</button>
                </form>
            </div>
        </div>
        
        <div id="logoutModal" class="modal" onclick="closeModal(event, 'logout')">
            <div class="modal-content" onclick="event.stopPropagation()" style="max-width: 400px;">
                <h2>🔓 Logout Options</h2>
                <p style="color: #888; margin: 1.5rem 0;">Choose how you'd like to logout:</p>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <button style="background: var(--accent); color: #000; padding: 12px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;" onclick="logoutCurrentSession()">
                        Logout from This Session
                    </button>
                    <button style="background: var(--danger); color: white; padding: 12px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;" onclick="globalLogout()">
                        Global Logout (All Sessions)
                    </button>
                    <button style="background: #555; color: white; padding: 12px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;" onclick="closeModal(null, 'logout')">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
        
        <script>
            const userId = sessionStorage.getItem('user_id');
            const orgId = sessionStorage.getItem('org_id');
            
            async function initDashboard() {
                const userName = sessionStorage.getItem('user_name');
                
                if (!userName) {
                    window.location.href = '/owner/login';
                    return;
                }
                
                document.getElementById('userName').textContent = userName;
                const orgName = sessionStorage.getItem('org_name') || 'Enterprise';
                document.getElementById('orgNameBanner').textContent = orgName.toUpperCase();
                
                window.globalView = false;
                
                // Set up toast container if not exists
                if (!document.getElementById('toastContainer')) {
                    const container = document.createElement('div');
                    container.id = 'toastContainer';
                    container.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:10000;';
                    document.body.appendChild(container);
                }

                // Initial load
                await refreshDashboardData();
                
                // Set up periodic refresh every 10 seconds
                setInterval(refreshDashboardData, 10000);
            }

            function showToast(message, type = 'info') {
                const toast = document.createElement('div');
                toast.style.cssText = `
                    background: ${type === 'danger' ? '#ff4444' : '#222'};
                    color: white; padding: 12px 20px; border-radius: 8px; 
                    margin-top: 10px; border-left: 4px solid var(--accent);
                    font-size: 0.9rem; min-width: 250px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
                    animation: slideIn 0.3s ease-out;
                `;
                toast.innerHTML = `<strong>AI AGENT:</strong> ${message}`;
                document.getElementById('toastContainer').appendChild(toast);
                setTimeout(() => {
                    toast.style.animation = 'fadeOut 0.3s ease-in';
                    setTimeout(() => toast.remove(), 300);
                }, 4000);
            }

            async function refreshDashboardData() {
                const syncText = document.getElementById('syncText');
                if (syncText) syncText.textContent = 'SYNCING...';
                
                try {
                    // Fetch consolidated stats
                    const response = await fetch(`/api/dashboard/stats/${window.globalView ? 'GLOBAL' : orgId}`);
                    const result = await response.json();
                    
                    if (result.status === 'success') {
                        const stats = result; // API returns flat object now
                        
                        // Update Header Stats
                        document.getElementById('activeUsers').textContent = stats.active_sessions_count;
                        document.getElementById('lastUpdate').textContent = stats.last_update;
                        
                        const securityValue = document.getElementById('securityScore');
                        if (stats.high_risk_sessions > 0) {
                            securityValue.textContent = (98 - (stats.high_risk_sessions * 10)) + '%';
                            securityValue.style.color = 'var(--danger)';
                            // Trigger banner if critical
                            if (stats.high_risk_sessions >= 1) {
                                const criticalSession = stats.sessions.find(s => s.status === 'CRITICAL_RISK');
                                if (criticalSession) {
                                    showAIAlert(criticalSession);
                                    if (!window.alertSent || window.alertSent !== criticalSession.session_id) {
                                        showToast(`URGENT: Suspicious activity detected from ${criticalSession.location}!`, 'danger');
                                        window.alertSent = criticalSession.session_id;
                                    }
                                }
                            }
                        } else {
                            securityValue.textContent = '98%';
                            securityValue.style.color = 'var(--success)';
                            document.getElementById('aiAlert').style.display = 'none';
                            window.alertSent = null;
                        }

                        // Update Workforce Table
                        updateWorkforceTable(stats.workforce);

                        // Update Sessions Audit (Identity Guardian)
                        updateSessionAudit(stats.sessions);

                        // Update Live Team Updates
                        updateLiveFeed(stats.updates);

                        // Update Executive Schedule
                        updateSchedule(stats.schedule || []);

                        // Update Growth Metrics
                        updateGrowthMetrics(stats.team_metrics);

                        // Update Performance
                        updatePerformanceList(stats.workforce || []); // stats.workforce IS the list

                        // Update Management Badges
                        updateBadges(stats.pending_leaves_count, stats.complaints.length || 0);
                    }
                    
                    if (syncText) syncText.textContent = 'LIVE';
                } catch (err) {
                    console.error('Refresh failed:', err);
                    if (syncText) syncText.textContent = 'OFFLINE';
                }
            }

            function updateWorkforceTable(workforce) {
                const table = document.getElementById('workforceTable');
                if (!table) return;
                table.innerHTML = '';
                
                // workforce is a list of employee objects
                if (!Array.isArray(workforce)) return;

                // Show up to 15 employees (all from the CSV)
                workforce.slice(0, 15).forEach(emp => {
                    const statusColor = emp.status === 'Active' ? 'var(--success)' : 
                                      (emp.status === 'Offline' ? '#888' : 'var(--warning)');
                    table.innerHTML += `
                        <tr style="color: #ccc; border-bottom: 1px solid #222;">
                            <td style="padding: 0.8rem 0;">
                                <div>${emp.name}</div>
                                <div style="font-size: 0.7rem; color: #666;">${emp.department || 'Staff'}</div>
                            </td>
                            <td style="padding: 0.8rem 0;"><span style="color: ${statusColor};">● ${emp.status.toUpperCase()}</span></td>
                            <td style="padding: 0.8rem 0; font-size: 0.8rem; color: #888;">${emp.clock_in || 'N/A'} (Total: ${emp.hours || '0h'})</td>
                            <td style="padding: 0.8rem 0;"><button class="btn-action" onclick="blockEmployee('${emp.id}')" style="width: auto; padding: 4px 12px; font-size: 0.7rem;">REVOKE</button></td>
                        </tr>
                    `;
                });
            }

            function updateSessionAudit(sessions) {
                const auditDiv = document.getElementById('sessionAudit');
                if (!auditDiv) return;
                auditDiv.innerHTML = '';
                
                if (!sessions || sessions.length === 0) {
                    auditDiv.innerHTML = '<div style="padding: 2rem; text-align: center; color: #555;">No active sessions</div>';
                    return;
                }

                sessions.slice(0, 4).forEach(s => {
                    const riskClass = s.threat_level === 'CRITICAL' ? 'risk-critical' : 
                                    s.threat_level === 'WARNING' ? 'risk-warning' : 'risk-secure';
                    auditDiv.innerHTML += `
                        <div class="session-item" style="display: flex; justify-content: space-between; align-items: center; border-left: 3px solid ${riskClass === 'risk-secure' ? 'var(--success)' : (riskClass === 'risk-warning' ? 'var(--warning)' : 'var(--danger)')}">
                            <div>
                                <div style="font-weight: 600; font-size: 0.9rem;">${s.user} <span style="font-weight: 400; color: #666; font-size: 0.75rem;">(${s.ip})</span></div>
                                <div style="font-size: 0.8rem; color: #888;">📍 ${s.location} | 🖥️ ${s.device}</div>
                            </div>
                            <span class="session-risk ${riskClass}">${s.threat_level}</span>
                        </div>
                    `;
                });
            }

            function updateLiveFeed(updates) {
                const container = document.getElementById('liveUpdates');
                if (!container) return;
                container.innerHTML = '';
                if (!updates) return;
                updates.forEach(u => {
                    container.innerHTML += `<div style="color: #aaa; padding: 0.6rem 0; border-bottom: 1px solid #1a1a1a; font-size: 0.85rem;">⚡ ${u}</div>`;
                });
            }

            function updateSchedule(schedule) {
                const container = document.getElementById('executiveSchedule');
                if (!container) return;
                
                if (!schedule || schedule.length === 0) {
                    container.innerHTML = '<div style="padding: 1rem; color: #555;">No events today</div>';
                    return;
                }

                container.innerHTML = '';
                schedule.forEach(ev => {
                    const statusColor = ev.status === 'Confirmed' ? 'var(--success)' : 'var(--warning)';
                    const typeLabel = ev.type || ev.category || 'General';
                    container.innerHTML += `
                        <div class="session-item">
                            <div style="color: var(--accent); font-weight: 600;">${ev.title}</div>
                            <div style="color: #888; font-size: 0.85rem;">${ev.time} - ${typeLabel}</div>
                            <span style="display: inline-block; background: rgba(0, 0, 0, 0.3); color: ${statusColor}; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; margin-top: 0.5rem; border: 1px solid ${statusColor}44;">${ev.status}</span>
                        </div>
                    `;
                });
            }

            function updateGrowthMetrics(growth) {
                const growthEl = document.getElementById('revenueGrowth');
                const projectEl = document.getElementById('revenueProjection');
                if (growthEl && growth.mom_growth) growthEl.textContent = `↗ ${growth.mom_growth} MoM`;
                if (projectEl && growth.revenue_projection) projectEl.textContent = growth.revenue_projection;
            }
            function updateBadges(leaves, complaints) {
                const leaveBadge = document.getElementById('leaveBadge');
                const complaintBadge = document.getElementById('complaintBadge');
                
                if (leaveBadge) {
                    if (leaves > 0) {
                        leaveBadge.textContent = leaves;
                        leaveBadge.style.display = 'block';
                    } else {
                        leaveBadge.style.display = 'none';
                    }
                }
                
                if (complaintBadge) {
                    if (complaints > 0) {
                        complaintBadge.textContent = complaints;
                        complaintBadge.style.display = 'block';
                    } else {
                        complaintBadge.style.display = 'none';
                    }
                }
            }

            async function updatePerformanceList(workforceList) {
                const container = document.getElementById('employeePerformance');
                if (!container) return;
                
                // Optimization: Only refresh performance every 5th sync cycle to save resources
                if (window.perfCounter === undefined) window.perfCounter = 0;
                window.perfCounter++;
                if (window.perfCounter % 5 !== 1) return; 

                container.innerHTML = '';
                if (!Array.isArray(workforceList)) return;

                for (let i = 0; i < Math.min(workforceList.length, 5); i++) {
                    const emp = workforceList[i];
                    try {
                        const res = await fetch(`/api/performance/employee/${emp.id}`);
                        const perf = await res.json();
                        if (perf.status === 'success' && perf.performance_records.length > 0) {
                            const p = perf.performance_records[0];
                            container.innerHTML += `
                                <div class="employee-perf">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                        <span class="emp-name">${p.employee_name || emp.name}</span>
                                        <span style="color: var(--accent); font-weight: 700;">${p.productivity_score}/10</span>
                                    </div>
                                    <div style="height: 4px; background: #222; border-radius: 2px;">
                                        <div style="height: 100%; width: ${p.productivity_score * 10}%; background: var(--accent); border-radius: 2px;"></div>
                                    </div>
                                </div>
                            `;
                        }
                    } catch (e) {}
                }
            }
            
            // --- NEW INTERACTIVE FUNCTIONS ---

            async function manageEmployees() {
                document.getElementById('manageEmployeesModal').style.display = 'flex';
                const list = document.getElementById('manageEmployeesList');
                list.innerHTML = 'Loading...';
                
                try {
                    const res = await fetch(`/api/dashboard/stats/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = '';
                        data.workforce.forEach(emp => {
                            html += `
                                <div class="session-item" style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-weight: 600;">${emp.name}</div>
                                        <div style="font-size: 0.8rem; color: #666;">ID: ${emp.id} | Dept: ${emp.department}</div>
                                    </div>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button class="btn-action" style="padding: 4px 10px;" onclick="viewEmployeeProfile('${emp.id}')">EDIT</button>
                                        <button class="btn-action" style="padding: 4px 10px; background: #444;" onclick="blockEmployee('${emp.id}')">LOCK</button>
                                    </div>
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    }
                } catch (e) {
                    list.innerHTML = 'Error loading employee data.';
                }
            }

            async function viewAttendance() {
                document.getElementById('attendanceModal').style.display = 'flex';
                const list = document.getElementById('attendanceLogs');
                list.innerHTML = 'Loading...';
                
                try {
                    const res = await fetch(`/api/attendance/org/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = '';
                        // Mocking detailed logs from workforce data for visualization
                        data.records.forEach(r => {
                            html += `
                                <div class="session-item">
                                    <div style="display: flex; justify-content: space-between;">
                                        <strong>${r.name}</strong>
                                        <span style="color: var(--success); font-size: 0.8rem;">${r.status}</span>
                                    </div>
                                    <div style="font-size: 0.85rem; color: #888; margin-top: 0.3rem;">
                                        Clocked-in at ${r.clock_in} | Total: ${r.hours || 'N/A'}
                                    </div>
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    }
                } catch (e) {
                    list.innerHTML = 'Error loading attendance logs.';
                }
            }

            function toggleGlobalWorkforce() {
                window.globalView = !window.globalView;
                const btn = document.getElementById('toggleGlobalView');
                btn.textContent = `GLOBAL VIEW: ${window.globalView ? 'ON' : 'OFF'}`;
                btn.style.background = window.globalView ? 'var(--accent)' : '#222';
                btn.style.color = window.globalView ? '#000' : '#fff';
                showToast(`Global Workforce Tracking ${window.globalView ? 'Enabled' : 'Disabled'}`, 'info');
                refreshDashboardData(); // Immediate refresh
            }

            async function viewPayroll() {
                document.getElementById('payrollModal').style.display = 'flex';
                const list = document.getElementById('payrollList');
                list.innerHTML = 'Establishing secure link to Finance Agent...';
                
                try {
                    const res = await fetch(`/api/payroll/org/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = `
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 2rem; background: rgba(0,0,0,0.3); padding: 1.5rem; border-radius: 12px; border: 1px solid #333;">
                                <div>
                                    <div style="font-size: 0.75rem; color: #888; text-transform: uppercase;">Total Payout</div>
                                    <div style="font-size: 1.5rem; font-weight: 700; color: var(--success);">₹${data.total_payout.toLocaleString()}</div>
                                </div>
                                <div style="border-left: 1px solid #333; padding-left: 1rem;">
                                    <div style="font-size: 0.75rem; color: #888; text-transform: uppercase;">Pending Liabilities</div>
                                    <div style="font-size: 1.5rem; font-weight: 700; color: var(--warning);">₹${data.pending_payout.toLocaleString()}</div>
                                </div>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                <h4 style="color: #888; text-transform: uppercase; font-size: 0.8rem;">Employee Breakdown (${data.employee_count})</h4>
                                <button class="btn-sessions" style="width: auto; padding: 5px 15px; font-size: 0.7rem;" onclick="generateMonthlyPayroll()">+ GENERATE PAYROLL</button>
                            </div>
                        `;
                        
                        if (data.payroll_records.length === 0) {
                            html += '<div style="padding: 2rem; text-align: center; color: #555;">No payroll records found for this organization.</div>';
                        } else {
                            data.payroll_records.forEach(p => {
                                const statusColor = p.status === 'paid' ? 'var(--success)' : 'var(--warning)';
                                html += `
                                    <div class="session-item" style="display: flex; justify-content: space-between; align-items: center; border-left: 3px solid ${statusColor === 'var(--success)' ? 'var(--success)' : 'var(--warning)'}">
                                        <div>
                                            <div style="font-weight: 600;">${p.name}</div>
                                            <div style="font-size: 0.8rem; color: #666;">Month: ${p.month} | Days: ${p.days_attended}/${p.working_days}</div>
                                        </div>
                                        <div style="text-align: right;">
                                            <div style="color: var(--accent); font-weight: 600;">₹${(p.net_salary || 0).toLocaleString()}</div>
                                            <div style="font-size: 0.75rem; color: ${statusColor}; font-weight: 600;">${p.status.toUpperCase()}</div>
                                            ${p.status === 'pending' ? `<button class="btn-action" style="padding: 2px 8px; font-size: 0.65rem; margin-top: 5px; background: #333;" onclick="processPayout('${p.emp_id}', '${p.month}')">PAY</button>` : ''}
                                        </div>
                                    </div>
                                `;
                            });
                        }
                        list.innerHTML = html;
                    }
                } catch (e) { 
                    console.error(e);
                    list.innerHTML = '<div style="color: var(--danger); padding: 2rem; text-align: center;">Error connecting to Finance Agent. Check server logs.</div>'; 
                }
            }
            
            async function generateMonthlyPayroll() {
                const month = prompt("Enter month (YYYY-MM):", new Date().toISOString().slice(0, 7));
                if (!month) return;
                
                try {
                    const res = await fetch('/api/payroll/generate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ org_id: orgId, month: month })
                    });
                    const result = await res.json();
                    if (result.status === 'success') {
                        showToast(result.message, 'success');
                        viewPayroll(); 
                    }
                } catch (e) { showToast('Error generating payroll', 'danger'); }
            }
            
            async function processPayout(empId, month) {
                if (!confirm(`Process payout for ${empId} for ${month}?`)) return;
                
                try {
                    const res = await fetch('/api/payroll/pay', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ emp_id: empId, month: month })
                    });
                    const result = await res.json();
                    if (result.status === 'success') {
                        showToast('Payment successful!', 'success');
                        viewPayroll();
                        refreshDashboardData();
                    }
                } catch (e) { showToast('Payment failed', 'danger'); }
            }

            async function viewLeaveRequests() {
                document.getElementById('leaveApprovalsModal').style.display = 'flex';
                const list = document.getElementById('leaveRequestsList');
                list.innerHTML = 'Loading...';
                
                try {
                    const res = await fetch(`/api/leave/org/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = '';
                        if (data.leave_requests.length === 0) {
                            list.innerHTML = '<div style="padding: 2rem; text-align: center; color: #555;">No pending leave requests</div>';
                            return;
                        }
                        data.leave_requests.forEach(l => {
                            const statusColor = l.status === 'pending' ? 'var(--warning)' : (l.status === 'approved' ? 'var(--success)' : 'var(--danger)');
                            html += `
                                <div class="session-item">
                                    <div style="display: flex; justify-content: space-between;">
                                        <strong>${l.name || l.emp_name || 'Anonymous Employee'}</strong>
                                        <span style="color: ${statusColor}; font-size: 0.8rem; font-weight: 600;">${l.status.toUpperCase()}</span>
                                    </div>
                                    <div style="font-size: 0.85rem; color: #ccc; margin: 0.5rem 0;">
                                        ${l.leave_type}: ${l.start_date} to ${l.end_date} 
                                    </div>
                                    <p style="font-size: 0.8rem; color: #777; font-style: italic;">"${l.reason}"</p>
                                    ${l.status === 'pending' ? `
                                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                                            <button class="btn-action" style="background: var(--success); color: #000; flex: 1;" onclick="updateLeaveStatus('${l.id}', 'approved')">APPROVE</button>
                                            <button class="btn-action" style="background: var(--danger); color: white; flex: 1;" onclick="updateLeaveStatus('${l.id}', 'rejected')">REJECT</button>
                                        </div>
                                    ` : ''}
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    }
                } catch (e) { list.innerHTML = 'Error loading leaves.'; }
            }

            async function updateLeaveStatus(leaveId, status) {
                try {
                    const res = await fetch(`/api/leave/update/${leaveId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ status: status })
                    });
                    const result = await res.json();
                    if (result.status === 'success') {
                        showToast(`Leave request ${status} successfully!`, 'success');
                        viewLeaveRequests(); // Refresh list
                        refreshDashboardData(); // Update badges
                    } else {
                        showToast(`Failed to update leave: ${result.message}`, 'danger');
                    }
                } catch (e) { 
                    console.error(e);
                    showToast('Network error while updating leave.', 'danger');
                }
            }

            function addEvent() {
                document.getElementById('addEventModal').style.display = 'flex';
                document.getElementById('eventForm').onsubmit = async (e) => {
                    e.preventDefault();
                    const title = document.getElementById('eventTitle').value;
                    const time = document.getElementById('eventTime').value;
                    const cat = document.getElementById('eventCategory').value;
                    
                    try {
                        const res = await fetch('/api/schedule/add', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ title, time, type: cat, org_id: orgId })
                        });
                        if (res.ok) {
                            alert('Event scheduled successfully!');
                            closeModal(null, 'addEvent');
                            refreshDashboardData();
                        }
                    } catch (err) { alert('Error scheduling event'); }
                };
            }

            async function viewComplaints() {
                document.getElementById('complaintsModal').style.display = 'flex';
                const list = document.getElementById('complaintsList');
                list.innerHTML = 'Loading...';
                
                try {
                    const res = await fetch(`/api/dashboard/stats/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = '';
                        data.complaints.forEach(c => {
                            const priorityColor = c.priority === 'High' ? 'var(--danger)' : (c.priority === 'Medium' ? 'var(--warning)' : 'var(--success)');
                            html += `
                                <div class="session-item">
                                    <div style="display: flex; justify-content: space-between;">
                                        <strong>${c.user}</strong>
                                        <span style="color: ${priorityColor}; font-size: 0.75rem; border: 1px solid ${priorityColor}; padding: 2px 6px; border-radius: 4px;">${c.priority.toUpperCase()}</span>
                                    </div>
                                    <div style="margin: 0.5rem 0; font-size: 0.9rem; line-height: 1.4;">${c.issue}</div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #1a1a1a; padding-top: 0.5rem; margin-top: 0.5rem;">
                                        <span style="font-size: 0.75rem; color: #555;">AI SENTIMENT: <strong style="color: #888;">${c.sentiment.toUpperCase()}</strong></span>
                                        <button class="btn-action" style="padding: 2px 8px; font-size: 0.7rem;" onclick="resolveComplaint('${c.id}')">RESOLVE</button>
                                    </div>
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    }
                } catch (e) { list.innerHTML = 'Error loading complaints.'; }
            }

            async function resolveComplaint(id) {
                if (confirm('Mark this complaint as resolved?')) {
                    try {
                        const res = await fetch(`/api/complaint/resolve/${id}`, { method: 'POST' });
                        if (res.ok) {
                            alert('Complaint resolved!');
                            viewComplaints();
                        }
                    } catch (e) {}
                }
            }

            function viewPerformance() {
                // For a "real project," we can show a detailed table or stats summary
                document.getElementById('manageEmployeesModal').style.display = 'flex';
                // Using employee modal as base for now or create a dedicated one
            }

            async function blockEmployee(empId) {
                if (confirm(`ARE YOU SURE? This will immediately revoke ALL active sessions for employee ${empId} and lock their account.`)) {
                    try {
                        const res = await fetch(`/api/revoke/employee/${empId}`, { method: 'POST' });
                        const result = await res.json();
                        if (result.status === 'success') {
                            alert(`IDENTITY SECURED: ${empId} has been blocked and sessions purged.`);
                            refreshDashboardData();
                        }
                    } catch (e) {
                        alert('Revoke failed');
                    }
                }
            }
            
            function showAIAlert(session) {
                const alertDiv = document.getElementById('aiAlert');
                if (!alertDiv) return;
                document.getElementById('alertTitle').textContent = `⚠️ AI ALERT: Suspicious activity detected from ${session.user}`;
                document.getElementById('alertDetail').textContent = `Location: ${session.location} | Device: ${session.device} | Risk Level: ${session.status}`;
                alertDiv.style.display = 'flex';
            }

            function viewOrgSessions() {
                document.getElementById('sessionsModal').style.display = 'flex';
                loadOrgSessionsList();
            }

            async function loadOrgSessionsList() {
                const list = document.getElementById('sessionsList');
                list.innerHTML = 'Establishing secure link to Identity Agent...';
                try {
                    const res = await fetch(`/api/sessions/org/${orgId}`);
                    const data = await res.json();
                    if (data.status === 'success') {
                        let html = '';
                        if (data.sessions.length === 0) {
                            list.innerHTML = '<div style="padding: 2rem; text-align: center; color: #555;">No active sessions detected by Guardian.</div>';
                            return;
                        }
                        data.sessions.forEach(s => {
                            const riskClass = s.threat_level === 'CRITICAL' ? 'risk-critical' : (s.threat_level === 'WARNING' ? 'risk-warning' : 'risk-secure');
                            html += `
                                <div class="session-item" style="border-left: 4px solid ${riskClass === 'risk-secure' ? 'var(--success)' : (riskClass === 'risk-warning' ? 'var(--warning)' : 'var(--danger)')}">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                        <div>
                                            <strong style="font-size: 1rem; color: var(--accent);">${s.user}</strong>
                                            <div style="font-size: 0.75rem; color: #666; font-family: monospace; margin-top: 2px;">SID: ${s.session_id}</div>
                                        </div>
                                        <span class="session-risk ${riskClass}" style="padding: 4px 10px; border-radius: 20px;">${s.threat_level}</span>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin: 1rem 0; font-size: 0.8rem; color: #aaa;">
                                        <div>📍 ${s.location}</div>
                                        <div>🖥️ ${s.device}</div>
                                        <div>📊 Risk: ${s.risk_score}%</div>
                                        <div>🕒 Active: ${new Date(s.last_activity).toLocaleTimeString()}</div>
                                    </div>
                                    <div style="background: rgba(0,0,0,0.2); padding: 8px; border-radius: 4px; font-size: 0.75rem; color: #888; margin-bottom: 10px; border: 1px dashed #333;">
                                        <span style="color: var(--accent-warm); font-weight: 600;">GUARDIAN ANALYSIS:</span> 
                                        ${s.risk_score > 50 ? 'Unusual behavioral pattern detected. Recommend immediate purge.' : 'Identity signature verified. Behavioral pattern consistent.'}
                                    </div>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button class="btn-action" style="flex: 2;" onclick="blockSession('${s.session_id}')">PURGE SESSION</button>
                                        <button class="btn-action" style="flex: 1; background: #333;" onclick="showToast('Agent is generating behavioral report...', 'info')">REPORT</button>
                                    </div>
                                </div>
                            `;
                        });
                        list.innerHTML = html;
                    }
                } catch (e) { list.innerHTML = 'Error communicating with Identity Agent.'; }
            }

            async function blockSession(sid) {
                if (confirm('Block this specific session?')) {
                    try {
                        const res = await fetch(`/api/logout/session/${sid}`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ user_id: userId })
                        });
                        if (res.ok) {
                            alert('Session terminated!');
                            loadOrgSessionsList();
                            refreshDashboardData();
                        }
                    } catch (e) {}
                }
            }

            function logoutConfirm() {
                document.getElementById('logoutModal').style.display = 'flex';
            }
            
            async function logoutCurrentSession() {
                const sessionId = sessionStorage.getItem('session_id');
                try {
                    const response = await fetch(`/api/logout/session/${sessionId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: userId })
                    });
                    if (response.ok) {
                        sessionStorage.clear();
                        window.location.href = '/owner/login';
                    }
                } catch (err) {
                    console.error('Logout failed:', err);
                }
            }
            
            async function globalLogout() {
                if (!confirm('Are you sure? This will logout from ALL sessions!')) return;
                try {
                    const response = await fetch(`/api/logout/global/${userId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });
                    if (response.ok) {
                        sessionStorage.clear();
                        window.location.href = '/owner/login';
                    }
                } catch (err) {
                    console.error('Global logout failed:', err);
                }
            }
            
            function closeModal(event, modalType) {
                if (event && event.target.id !== modalType + 'Modal') return;
                const modal = document.getElementById(modalType + 'Modal');
                if (modal) modal.style.display = 'none';
            }
            
            function setTheme(theme) {
                document.body.setAttribute('data-theme', theme);
                localStorage.setItem('agentic_theme', theme);
                
                document.querySelectorAll('.theme-dot').forEach(dot => {
                    dot.classList.remove('active');
                    if(dot.title.toLowerCase().includes(theme === 'default' ? 'blue' : theme)) {
                        dot.classList.add('active');
                    }
                });
            }

            // Restore theme
            const savedTheme = localStorage.getItem('agentic_theme') || 'default';
            setTheme(savedTheme);

            document.addEventListener('DOMContentLoaded', initDashboard);
        </script>
    </body>
    </html>
    """
    return html_content

# ============================================================================
# API ENDPOINTS - SESSION & LOGOUT MANAGEMENT
# ============================================================================

@app.post("/api/logout/session/{session_id}")
async def logout_session(session_id: str, request: Request):
    """Logout from a specific session with AI analysis"""
    data = await request.json()
    user_id = data.get("user_id")
    result = logout_flow(session_id, user_id)
    return result

@app.post("/api/logout/global/{user_id}")
async def global_logout(user_id: str):
    """AI-driven global logout - terminate all sessions"""
    result = global_logout_flow(user_id)
    return result

@app.get("/api/sessions/user/{user_id}")
async def get_user_sessions(user_id: str):
    """Get all active sessions for a user"""
    result = security_agent.get_user_active_sessions(user_id)
    return result

@app.get("/api/sessions/org/{org_id}")
async def get_org_sessions(org_id: str):
    """Get all active sessions for an organization"""
    result = security_agent.get_organization_active_sessions(org_id)
    return result

@app.get("/api/org/{org_id}/employees")
async def get_org_employees(org_id: str):
    """Get all employees of an organization"""
    employees = security_agent.get_org_employees(org_id)
    return {"status": "success", "employees": employees}

@app.get("/api/user/{user_id}/info")
async def get_user_info(user_id: str):
    """Get user information"""
    for org in security_agent.organizations:
        if org["owner"]["id"] == user_id:
            return {"status": "success", "user": org["owner"], "type": "owner"}
        
        for emp in org.get("employees", []):
            if emp["id"] == user_id:
                return {"status": "success", "user": emp, "type": "employee", "org_id": org["org_id"]}
    
    return {"status": "error", "message": "User not found"}

@app.get("/api/organizations")
async def get_all_organizations():
    """Get all organizations"""
    return {"status": "success", "organizations": security_agent.organizations}

# ============================================================================
# ATTENDANCE ENDPOINTS
# ============================================================================

@app.get("/api/attendance/employee/{emp_id}")
async def get_employee_attendance(emp_id: str):
    """Get employee attendance records"""
    return data_service.get_employee_attendance(emp_id)

@app.post("/api/attendance/mark")
async def mark_attendance(request: Request):
    """Mark attendance"""
    data = await request.json()
    emp_id = data.get("emp_id")
    action = data.get("action", "check_in")
    return data_service.mark_attendance(emp_id, action)

@app.get("/api/attendance/org/{org_id}")
async def get_org_attendance(org_id: str):
    """Get all org attendance"""
    try:
        org_employees = security_agent.get_org_employees(org_id)
        all_attendance = []
        for emp in org_employees:
            emp_att = data_service.get_employee_attendance(emp["id"])
            if emp_att["status"] == "success":
                all_attendance.extend(emp_att.get("records", []))
        
        return {
            "status": "success",
            "org_id": org_id,
            "total_records": len(all_attendance),
            "records": all_attendance
        }
    except:
        return {"status": "error", "message": "Failed to load attendance"}

# ============================================================================
# WORK SCHEDULE ENDPOINTS
# ============================================================================

@app.get("/api/schedule/employee/{emp_id}")
async def get_employee_schedule(emp_id: str):
    """Get employee schedule"""
    return data_service.get_employee_schedule(emp_id)

@app.get("/api/schedule/org/{org_id}")
async def get_org_schedule(org_id: str):
    """Get organization schedule"""
    return data_service.get_org_schedule(org_id)

# ============================================================================
# PAYROLL ENDPOINTS
# ============================================================================

@app.get("/api/payroll/employee/{emp_id}")
async def get_employee_payroll(emp_id: str):
    """Get employee payroll history via service"""
    return payroll_service.get_employee_payroll(emp_id)

@app.get("/api/payroll/org/{org_id}")
async def get_org_payroll(org_id: str):
    """Get comprehensive organization payroll summary"""
    return payroll_service.get_org_payroll_summary(org_id)

@app.post("/api/payroll/generate")
async def generate_payroll(request: Request):
    """Admin endpoint to generate monthly payroll for an organization"""
    data = await request.json()
    org_id = data.get("org_id")
    month = data.get("month")
    return payroll_service.generate_monthly_payroll(org_id, month)

@app.post("/api/payroll/pay")
async def process_payout(request: Request):
    """Admin endpoint to process a specific payroll payout"""
    data = await request.json()
    emp_id = data.get("emp_id")
    month = data.get("month")
    return payroll_service.process_payment(emp_id, month)

# ============================================================================
# LEAVE REQUEST ENDPOINTS
# ============================================================================

@app.get("/api/leave/employee/{emp_id}")
async def get_employee_leave_requests(emp_id: str):
    """Get employee leave requests"""
    return data_service.get_employee_leave_requests(emp_id)

@app.post("/api/leave/submit")
async def submit_leave_request(request: Request):
    """Submit a leave request"""
    data = await request.json()
    return data_service.submit_leave_request(
        emp_id=data.get("emp_id"),
        emp_name=data.get("emp_name"),
        leave_type=data.get("leave_type"),
        start_date=data.get("start_date"),
        end_date=data.get("end_date"),
        reason=data.get("reason")
    )

@app.get("/api/leave/org/{org_id}")
async def get_org_leave_requests(org_id: str):
    """Get organization leave requests"""
    return data_service.get_org_leave_requests(org_id)

# ============================================================================
# PERFORMANCE ENDPOINTS
# ============================================================================

@app.get("/api/performance/employee/{emp_id}")
async def get_employee_performance(emp_id: str):
    """Get employee performance"""
    return data_service.get_employee_performance(emp_id)

@app.get("/api/performance/org/{org_id}")
async def get_org_performance(org_id: str):
    """Get organization performance"""
    return data_service.get_org_performance(org_id)

# ============================================================================
# COMPLAINT ENDPOINTS
# ============================================================================

@app.post("/api/complaint/submit")
async def submit_complaint(request: Request):
    """Submit a complaint with AI analysis via orchestrator"""
    data = await request.json()
    
    # Still log in data_service for history
    data_service.submit_complaint(
        emp_id=data.get("emp_id"),
        emp_name=data.get("username", data.get("emp_name")),
        title=data.get("title"),
        description=data.get("description")
    )
    
    # Process with AI
    return complaint_flow(data)

@app.get("/api/complaint/employee/{emp_id}")
async def get_employee_complaints(emp_id: str):
    """Get employee complaints"""
    return data_service.get_employee_complaints(emp_id)

@app.get("/api/complaint/org/{org_id}")
async def get_org_complaints(org_id: str):
    """Get organization complaints"""
    return data_service.get_org_complaints(org_id)

# ============================================================================
# PRODUCTIVITY & REAL-TIME ENDPOINTS
# ============================================================================

@app.get("/api/productivity/updates")
async def get_productivity_updates():
    """Get live team productivity updates"""
    return {"status": "success", "updates": productivity_agent.get_live_updates()}

@app.post("/api/leave/update/{leave_id}")
async def update_leave_status_api(leave_id: str, request: Request):
    """Approve or reject a leave request through DataService"""
    data = await request.json()
    status = data.get("status")
    return data_service.update_leave_status(leave_id, status)

@app.post("/api/complaint/resolve/{complaint_id}")
async def resolve_complaint_api(complaint_id: str):
    """Mark a complaint as resolved"""
    # 1. Resolve in ComplaintAgent
    agent_res = complaint_agent.resolve_complaint(complaint_id)
    
    # 2. Sync with data_service history
    complaints_path = os.path.join(data_service.data_dir, "complaints.json")
    if os.path.exists(complaints_path):
        with open(complaints_path, "r") as f:
            data_file = json.load(f)
        
        for c in data_file:
            if c["id"] == complaint_id:
                c["status"] = "resolved"
                c["updated_date"] = datetime.now().isoformat()
                break
        
        with open(complaints_path, "w") as f:
            json.dump(data_file, f, indent=2)
            
    return agent_res

@app.post("/api/revoke/employee/{emp_id}")
async def revoke_employee_api(emp_id: str):
    """Global revocation of employee access"""
    from orchestrator.agent_router import revoke_flow
    return revoke_flow(emp_id)

@app.post("/api/schedule/add")
async def add_schedule_event(request: Request):
    """Add a new event to the executive schedule"""
    data = await request.json()
    # Logic is handled in scheduling_agent
    return scheduling_agent.add_event(data)

@app.get("/api/dashboard/stats/{org_id}")
async def get_dashboard_bundle(org_id: str):
    """Get a consolidated bundle of all dynamic dashboard stats using orchestrator"""
    # Calculate pending leaves first to feed into dynamic agents
    leave_requests = data_service.get_org_leave_requests(org_id).get("leave_requests", [])
    pending_leaves = len([l for l in leave_requests if l.get("status") == "pending"])
    
    # Pass to orchestrator for dynamic agent logic
    bundle = dashboard_flow(org_id, pending_leaves_count=pending_leaves)
    
    # Calculate additional metrics for UI
    sessions = bundle.get("sessions", [])
    high_risk_count = len([s for s in sessions if s.get("status") == "CRITICAL_RISK"])
    
    return {
        "status": "success",
        "active_sessions_count": len(sessions),
        "high_risk_sessions": high_risk_count,
        "team_metrics": bundle.get("enterprise_metrics", {}),
        "updates": bundle.get("updates", []),
        "finance_risk": bundle.get("finance_risk", {}),
        "workforce": bundle.get("workforce", []),
        "complaints": bundle.get("complaints", []),
        "sessions": sessions,
        "schedule": bundle.get("schedule", []),
        "pending_leaves_count": pending_leaves,
        "last_update": datetime.now().strftime("%H:%M:%S")
    }

