from agents.security_agent import SecurityAgent
from agents.attendance_agent import AttendanceAgent
from agents.productivity_agent import ProductivityAgent
from agents.complaint_agent import ComplaintAgent
from agents.payroll_agent import PayrollAgent
from agents.growth_agent import GrowthAgent
from agents.scheduling_agent import SchedulingAgent

security_agent = SecurityAgent()
attendance_agent = AttendanceAgent()
productivity_agent = ProductivityAgent()
complaint_agent = ComplaintAgent()
payroll_agent = PayrollAgent()
growth_agent = GrowthAgent()
scheduling_agent = SchedulingAgent()


def org_login_flow(data: dict):
    """Consolidated organization login flow (Owner/Employee)"""
    result = security_agent.verify_org_login(data)
    
    if result.get("status") == "allowed":
        user_id = result.get("user_id")
        # Mark attendance/activity in other agents
        sync_data = {
            "employee_id": user_id,
            "username": result.get("user_name"),
            "org_id": result.get("org_id")
        }
        attendance_agent.mark_attendance(sync_data)
        productivity_agent.track_productivity(sync_data)
        
    return result


def complaint_flow(data: dict):
    """
    Handle employee complaints via ComplaintAgent
    """
    result = complaint_agent.process_complaint(data)
    return {
        "status": "processed",
        "details": result
    }


def dashboard_flow(org_id: str = None, pending_leaves_count: int = 0):
    """
    Gather enterprise-wide metrics filtered by organization
    """
    workforce = attendance_agent.get_workforce_status(org_id)
    
    # Growth now reflects active users
    growth = growth_agent.company_growth(workforce_data=workforce)
    historical_performance = growth_agent.get_historical_performance()
    
    updates = productivity_agent.get_live_updates(workforce=workforce)
    complaints = complaint_agent.get_all_complaints() 
    
    # Finance Risk now reflects pending leaves
    finance_risk = payroll_agent.get_finance_risk(workforce=workforce, pending_leaves_count=pending_leaves_count)
    
    # Filter sessions by organization if provided
    if org_id:
        sessions_map = security_agent.get_all_sessions()
        sessions = [
            {"session_id": sid, **s} 
            for sid, s in sessions_map.items() 
            if s.get("org_id") == org_id
        ]
    else:
        sessions_map = security_agent.get_all_sessions()
        sessions = [{"session_id": sid, **s} for sid, s in sessions_map.items()]

    schedule = scheduling_agent.get_todays_schedule()
    
    return {
        "enterprise_metrics": growth,
        "historical_performance": historical_performance,
        "workforce": workforce,
        "updates": updates,
        "complaints": complaints,
        "finance_risk": finance_risk,
        "sessions": sessions,
        "schedule": schedule,
        "system_status": "operational"
    }

def revoke_flow(employee_id: str):
    # Update Security Layer (Rejects logins + Kills active sessions)
    sec_res = security_agent.revoke_access(employee_id)
    # Update Workforce Tracker (Removes from dashboard permanently)
    att_res = attendance_agent.revoke_employee(employee_id)
    return {
        "status": "success",
        "security": sec_res,
        "attendance": att_res,
        "message": f"Global Revocation Complete for {employee_id}"
    }

def kill_session_flow(session_id: str):
    return security_agent.kill_session(session_id)

def logout_flow(session_id: str, user_id: str = None):
    """Specific session logout with AI risk analysis"""
    return security_agent.logout_session(session_id, user_id)

def global_logout_flow(user_id: str):
    """Global AI-driven logout for a user across all sessions"""
    return security_agent.ai_global_logout(user_id)
